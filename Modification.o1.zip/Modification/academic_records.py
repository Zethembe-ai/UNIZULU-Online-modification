"""
STANDALONE ACADEMIC RECORDS SYSTEM
Add this as a separate file - no changes to your existing app.py needed
"""

from flask import jsonify, request, current_app
import sqlite3
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

def get_db_connection():
    """Standalone database connection"""
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def complete_module_automatic(username, module_code, final_mark, semester=None, academic_year=None):
    """
    Complete a module - automatic academic record creation
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get current semester if not provided
        if not semester or not academic_year:
            cursor.execute("""
                SELECT current_semester, current_academic_year 
                FROM current_semester_tracking 
                LIMIT 1
            """)
            current = cursor.fetchone()
            if current:
                semester = semester or current['current_semester']
                academic_year = academic_year or current['current_academic_year']
        
        # Calculate grade
        if final_mark >= 75:
            grade = 'A'
        elif final_mark >= 70:
            grade = 'B+'
        elif final_mark >= 65:
            grade = 'B'
        elif final_mark >= 60:
            grade = 'C+'
        elif final_mark >= 50:
            grade = 'C'
        elif final_mark >= 45:
            grade = 'D'
        else:
            grade = 'F'
        
        # Get module credits
        cursor.execute("SELECT credits FROM program_modules WHERE module_code = ?", (module_code,))
        module = cursor.fetchone()
        
        if not module:
            conn.close()
            return {'success': False, 'error': f'Module {module_code} not found'}
        
        credits_earned = module['credits'] if final_mark >= 50 else 0
        
        # Update student_modules
        cursor.execute("""
            UPDATE student_modules
            SET status = 'completed',
                final_mark = ?,
                grade = ?,
                credits_earned = ?
            WHERE username = ? 
            AND module_code = ?
            AND academic_year = ?
            AND semester = ?
        """, (final_mark, grade, credits_earned, username, module_code, academic_year, semester))
        
        if cursor.rowcount == 0:
            conn.close()
            return {'success': False, 'error': 'Module registration not found'}
        
        conn.commit()
        
        # Get updated student info
        cursor.execute("SELECT total_credits_earned FROM students WHERE username = ?", (username,))
        student = cursor.fetchone()
        
        conn.close()
        
        return {
            'success': True,
            'message': f'Module {module_code} completed with grade {grade}',
            'data': {
                'username': username,
                'module_code': module_code,
                'final_mark': final_mark,
                'grade': grade,
                'credits_earned': credits_earned,
                'total_credits': student['total_credits_earned'] if student else 0
            }
        }
        
    except Exception as e:
        logger.error(f"Error completing module: {e}")
        return {'success': False, 'error': str(e)}

def get_student_transcript(username):
    """
    Get complete academic transcript
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get student info
        cursor.execute("""
            SELECT username, first_name, last_name, program_code, year_level
            FROM students WHERE username = ?
        """, (username,))
        
        student_info = cursor.fetchone()
        if not student_info:
            conn.close()
            return {'success': False, 'error': 'Student not found'}
        
        # Get academic records
        cursor.execute("""
            SELECT module_code, module_name, academic_year, semester,
                   final_mark, grade, credits_earned, status
            FROM student_modules 
            WHERE username = ? 
            ORDER BY academic_year DESC, semester DESC
        """, (username,))
        
        records = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        # Calculate statistics
        total_credits = sum(record['credits_earned'] or 0 for record in records)
        completed_modules = len([r for r in records if r['status'] == 'completed'])
        
        return {
            'success': True,
            'student': dict(student_info),
            'records': records,
            'summary': {
                'total_credits': total_credits,
                'completed_modules': completed_modules,
                'total_modules': len(records)
            },
            'generated_at': datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error generating transcript: {e}")
        return {'success': False, 'error': str(e)}

def get_failed_modules(username):
    """
    Get all failed modules for a student
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT module_code, module_name, academic_year, semester, final_mark
            FROM student_modules 
            WHERE username = ? AND grade = 'F'
            ORDER BY academic_year DESC, semester DESC
        """, (username,))
        
        failed = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return {
            'success': True,
            'username': username,
            'failed_modules': failed,
            'total_failed': len(failed)
        }
        
    except Exception as e:
        logger.error(f"Error getting failed modules: {e}")
        return {'success': False, 'error': str(e)}