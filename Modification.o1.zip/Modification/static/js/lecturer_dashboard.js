// lecturer_dashboard.js - Fixed Implementation with Fallback Handling

class LecturerDashboard {
    constructor() {
        this.currentLecturer = null;
        this.signaturePad = null;
        this.currentRequestId = null;
        this.filters = {
            status: 'all',
            module: 'all',
            date: 'all',
            historyStatus: 'all'
        };
        
        // Get initial data from Flask template
        this.initialData = {
            user: window.userData || {},
            requests: window.requestsData || [],
            assigned_modules: window.assignedModules || 0,
            pending_count: window.pendingCount || 0
        };
        
        this.init();
    }

    init() {
        this.loadLecturerData();
        this.setupEventListeners();
        this.setupSignaturePad();
        this.loadInitialData();
    }

    loadInitialData() {
        // Use initial data from Flask template for first load
        this.updateWelcomeMessage();
        this.updateNotificationBadge();
        this.loadDashboardOverview();
    }

    async loadLecturerData() {
        try {
            const response = await fetch('/api/lecturer/profile');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.currentLecturer = data.lecturer;
                    this.updateWelcomeMessage();
                    return;
                }
            }
        } catch (error) {
            console.error('Error loading lecturer data:', error);
        }
        
        // Fall back to template data
        this.currentLecturer = this.initialData.user;
        this.updateWelcomeMessage();
    }

    updateWelcomeMessage() {
        const lecturer = this.currentLecturer || this.initialData.user;
        
        const welcomeTitle = document.getElementById('welcome-title');
        const welcomeSubtitle = document.getElementById('welcome-subtitle');
        const profileAvatar = document.getElementById('profile-avatar');
        const lecturerName = document.getElementById('lecturer-name');
        const lecturerDept = document.getElementById('lecturer-department');
        
        // Update welcome title with lecturer's name
        if (welcomeTitle) {
            if (lecturer.name) {
                welcomeTitle.textContent = `Welcome, ${lecturer.name}! 👋`;
            } else if (lecturer.first_name && lecturer.surname) {
                welcomeTitle.textContent = `Welcome, ${lecturer.first_name} ${lecturer.surname}! 👋`;
            } else {
                welcomeTitle.textContent = `Welcome, Lecturer! 👋`;
            }
        }
        
        // Update profile avatar
        if (profileAvatar) {
            if (lecturer.name) {
                profileAvatar.textContent = lecturer.name.charAt(0).toUpperCase();
            } else if (lecturer.first_name) {
                profileAvatar.textContent = lecturer.first_name.charAt(0).toUpperCase();
            } else {
                profileAvatar.textContent = 'L';
            }
        }
        
        // Update lecturer name in profile section
        if (lecturerName) {
            if (lecturer.name) {
                lecturerName.textContent = lecturer.name;
            } else if (lecturer.first_name && lecturer.surname) {
                lecturerName.textContent = `${lecturer.first_name} ${lecturer.surname}`;
            } else {
                lecturerName.textContent = 'Loading...';
            }
        }
        
        // Update lecturer department
        if (lecturerDept) {
            lecturerDept.textContent = lecturer.department || 'University of Zululand';
        }
    }

    async updateNotificationBadge() {
        try {
            const response = await fetch('/api/lecturer/pending-count');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.updateBadge(data.count);
                    return;
                }
            }
        } catch (error) {
            console.error('Error updating notification badge:', error);
        }
        
        // Fallback to template data
        this.updateBadge(this.initialData.pending_count);
    }

    updateBadge(count) {
        const badge = document.getElementById('pendingRequestsBadge');
        if (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'flex' : 'none';
        }
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            if (!item.classList.contains('logout-btn')) {
                item.addEventListener('click', (e) => {
                    this.handleNavigation(e);
                });
            }
        });

        // Logout
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Dashboard actions
        document.getElementById('viewAllRequests')?.addEventListener('click', () => {
            this.switchToSection('module-requests');
        });

        // Filter events
        document.getElementById('statusFilter')?.addEventListener('change', (e) => {
            this.filters.status = e.target.value;
            this.loadModuleRequests();
        });

        document.getElementById('moduleFilter')?.addEventListener('change', (e) => {
            this.filters.module = e.target.value;
            this.loadModuleRequests();
        });

        document.getElementById('refreshRequests')?.addEventListener('click', () => {
            this.loadModuleRequests();
        });

        // Modal events
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                this.closeAllModals();
            });
        });

        document.getElementById('cancelSignature')?.addEventListener('click', () => {
            this.closeSignatureModal();
        });

        document.getElementById('clearSignature')?.addEventListener('click', () => {
            this.clearSignature();
        });

        document.getElementById('saveSignature')?.addEventListener('click', () => {
            this.saveSignature();
        });

        document.getElementById('closeDetails')?.addEventListener('click', () => {
            this.closeDetailsModal();
        });

        // Close modals when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeAllModals();
                }
            });
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    setupSignaturePad() {
        const canvas = document.getElementById('signatureCanvas');
        if (canvas) {
            // Configure signature pad for better writing experience
            this.signaturePad = new SignaturePad(canvas, {
                backgroundColor: 'rgb(255, 255, 255)',
                penColor: 'rgb(0, 0, 0)',
                minWidth: 1.5,
                maxWidth: 2.5,
                throttle: 16,
                velocityFilterWeight: 0.7,
                minDistance: 3
            });

            this.resizeSignatureCanvas();
            window.addEventListener('resize', () => this.resizeSignatureCanvas());

            // Add touch/mouse event listeners for better control
            this.enhanceSignaturePad();
        }
    }

    enhanceSignaturePad() {
        const canvas = document.getElementById('signatureCanvas');
        if (!canvas) return;

        // Prevent scrolling when signing on touch devices
        canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
        });

        canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
        });

        // Add pressure sensitivity for supported devices
        canvas.addEventListener('mousedown', () => {
            this.isDrawing = true;
        });

        canvas.addEventListener('mouseup', () => {
            this.isDrawing = false;
        });

        // Add instructions
        this.addSignatureInstructions();
    }

    addSignatureInstructions() {
        const signatureContainer = document.querySelector('.signature-pad-container');
        if (signatureContainer && !signatureContainer.querySelector('.signature-instructions')) {
            const instructions = document.createElement('div');
            instructions.className = 'signature-instructions';
            instructions.innerHTML = `
                <p><small>Sign in the box above using your mouse or touch screen</small></p>
            `;
            signatureContainer.appendChild(instructions);
        }
    }

    resizeSignatureCanvas() {
        const canvas = document.getElementById('signatureCanvas');
        if (canvas && this.signaturePad) {
            const ratio = Math.max(window.devicePixelRatio || 1, 1);
            const parent = canvas.parentElement;
            const width = parent.offsetWidth;
            const height = 200; // Fixed height for consistent signature area
            
            canvas.width = width * ratio;
            canvas.height = height * ratio;
            canvas.style.width = `${width}px`;
            canvas.style.height = `${height}px`;
            
            const context = canvas.getContext("2d");
            context.scale(ratio, ratio);
            context.imageSmoothingEnabled = true;
            context.imageSmoothingQuality = 'high';
            
            // Redraw existing signature if any
            if (!this.signaturePad.isEmpty()) {
                const data = this.signaturePad.toData();
                this.signaturePad.clear();
                this.signaturePad.fromData(data);
            }
        }
    }

    handleNavigation(event) {
        const target = event.currentTarget.getAttribute('data-target');
        this.switchToSection(target);
    }

    switchToSection(section) {
        // Update active nav item
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
            if (item.getAttribute('data-target') === section) {
                item.classList.add('active');
            }
        });
        
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        
        // Show target section
        const targetSection = document.getElementById(section);
        if (targetSection) {
            targetSection.classList.add('active');
            this.loadSectionContent(section);
        }
    }

    async loadSectionContent(section) {
        switch(section) {
            case 'dashboard':
                await this.loadDashboardOverview();
                break;
            case 'module-requests':
                await this.loadModuleRequests();
                break;
            case 'my-modules':
                await this.loadMyModules();
                break;
            case 'history':
                await this.loadReviewHistory();
                break;
        }
    }

    async loadDashboardOverview() {
        const section = document.getElementById('dashboard');
        if (!section) return;
        
        try {
            const response = await fetch('/api/lecturer/dashboard-overview');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    section.querySelector('.dashboard-overview').innerHTML = this.renderDashboardOverview(data.data);
                    this.attachDashboardEventListeners();
                    return;
                }
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
        
        // Fallback: Use template data for dashboard
        const statsGrid = section.querySelector('#statsGrid');
        
        if (statsGrid) {
            statsGrid.innerHTML = this.renderStatsCards();
        }
        
        this.attachDashboardEventListeners();
    }

    renderStatsCards() {
        const lecturer = this.currentLecturer || this.initialData.user;
        
        // Get lecturer name for display
        let lecturerDisplayName = 'Lecturer';
        if (lecturer.name) {
            lecturerDisplayName = lecturer.name;
        } else if (lecturer.first_name && lecturer.surname) {
            lecturerDisplayName = `${lecturer.first_name} ${lecturer.surname}`;
        }
        
        // Get lecturer department
        const lecturerDepartment = lecturer.department || 'Department';
        
        // Get lecturer email
        const lecturerEmail = lecturer.email || '';

        return `
            <div class="stat-card">
                <div class="stat-icon pending">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-info">
                    <h3>${this.initialData.pending_count || 0}</h3>
                    <p>Pending Requests</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon assigned">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-info">
                    <h3>${this.initialData.assigned_modules || 0}</h3>
                    <p>Assigned Modules</p>
                </div>
            </div>
            <div class="lecturer-info-card">
                <div class="lecturer-avatar">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="lecturer-details">
                    <h3>${lecturerDisplayName}</h3>
                    <p>${lecturerDepartment}</p>
                    ${lecturerEmail ? `<p class="lecturer-email">${lecturerEmail}</p>` : ''}
                </div>
            </div>
        `;
    }

    renderDashboardOverview(data) {
        const lecturer = this.currentLecturer || this.initialData.user;
        
        // Get lecturer name for display
        let lecturerDisplayName = 'Lecturer';
        if (lecturer.name) {
            lecturerDisplayName = lecturer.name;
        } else if (lecturer.first_name && lecturer.surname) {
            lecturerDisplayName = `${lecturer.first_name} ${lecturer.surname}`;
        }
        
        // Get lecturer department
        const lecturerDepartment = lecturer.department || 'Department';
        
        // Get lecturer email
        const lecturerEmail = lecturer.email || '';

        return `
            <div class="stats-grid" id="statsGrid">
                <div class="stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>${data.pending_requests || 0}</h3>
                        <p>Pending Requests</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon assigned">
                        <i class="fas fa-book"></i>
                    </div>
                    <div class="stat-info">
                        <h3>${data.assigned_modules || 0}</h3>
                        <p>Assigned Modules</p>
                    </div>
                </div>
                <div class="lecturer-info-card">
                    <div class="lecturer-avatar">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="lecturer-details">
                        <h3>${lecturerDisplayName}</h3>
                        <p>${lecturerDepartment}</p>
                        ${lecturerEmail ? `<p class="lecturer-email">${lecturerEmail}</p>` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    attachDashboardEventListeners() {
        document.querySelectorAll('.view-details').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const requestId = e.target.closest('.request-card').dataset.requestId;
                this.viewRequestDetails(requestId);
            });
        });

        document.querySelectorAll('.sign-request').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const requestId = e.target.closest('.request-card').dataset.requestId;
                this.openSignatureModal(requestId);
            });
        });
    }

    async loadModuleRequests() {
        const container = document.getElementById('requestsContainer');
        if (!container) return;
        
        container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><h3>Loading Requests...</h3></div>';
        
        try {
            const params = new URLSearchParams();
            if (this.filters.status !== 'all') params.append('status', this.filters.status);
            if (this.filters.module !== 'all') params.append('module', this.filters.module);
            
            const response = await fetch(`/api/lecturer/module-requests?${params}`);
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    container.innerHTML = this.renderModuleRequests(data.requests);
                    this.attachRequestEventListeners();
                    this.updateModuleFilterOptions(data.modules);
                    return;
                }
            }
        } catch (error) {
            console.error('Error loading module requests:', error);
        }
        
        // Fallback: Use template data
        let filteredRequests = this.initialData.requests || [];
        
        if (this.filters.status !== 'all') {
            filteredRequests = filteredRequests.filter(req => req.request_status === this.filters.status);
        }
        
        container.innerHTML = this.renderModuleRequests(filteredRequests);
        this.attachRequestEventListeners();
    }

    renderModuleRequests(requests) {
        if (!requests || requests.length === 0) {
            return `
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>No Pending Requests</h3>
                    <p>There are no module requests awaiting your review at this time.</p>
                </div>
            `;
        }

        return `
            <div class="requests-grid">
                ${requests.map(request => this.renderRequestCard(request)).join('')}
            </div>
        `;
    }

    renderRequestCard(request) {
        // Handle both API response format and template format
        const requestId = request.request_id || request.id;
        const studentName = `${request.student_first_name || request.first_name || ''} ${request.student_last_name || request.surname || ''}`.trim();
        const studentUsername = request.student_username || request.student_number;
        const moduleCode = request.module_code || request.subject_code;
        const moduleName = request.module_name || request.subject_name;
        const programCode = request.program_code || request.qualification;
        const yearLevel = request.year_level;
        const requestType = request.request_type;
        const reason = request.reason;
        const status = request.request_status || request.status;
        const createdDate = request.request_date || request.created_at;

        const isUrgent = this.isRequestUrgent(createdDate);
        const statusClass = this.getStatusClass(status);
        
        return `
            <div class="request-card ${isUrgent ? 'urgent' : ''}" data-request-id="${requestId}">
                <div class="request-header">
                    <div class="student-info">
                        <h4>${studentName || 'Unknown Student'}</h4>
                        <span class="student-id">${studentUsername || 'N/A'}</span>
                    </div>
                    <div class="request-meta">
                        <span class="status-badge ${statusClass}">${(status || '').replace('_', ' ')}</span>
                        <span class="request-date">${new Date(createdDate).toLocaleTimeString()}</span>
                    </div>
                </div>
                
                <div class="request-details">
                    <div class="detail-row">
                        <label>Module:</label>
                        <span><strong>${moduleCode || 'N/A'}</strong> - ${moduleName || 'Unknown Module'}</span>
                    </div>
                    <div class="detail-row">
                        <label>Program:</label>
                        <span>${programCode || 'N/A'} ${yearLevel ? `(Year ${yearLevel})` : ''}</span>
                    </div>
                    <div class="detail-row">
                        <label>Request Type:</label>
                        <span class="request-type ${requestType}">${(requestType || '').toUpperCase()}</span>
                    </div>
                    <div class="detail-row">
                        <label>Reason:</label>
                        <p class="reason-text">${reason || 'No reason provided'}</p>
                    </div>
                </div>
                
                <div class="request-actions">
                    <button class="btn btn-outline view-details">
                        <i class="fas fa-eye"></i> Details
                    </button>
                    ${status === 'pending_lecturer' ? `
                        <button class="btn btn-primary sign-request">
                            <i class="fas fa-signature"></i> Sign Request
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    }

    attachRequestEventListeners() {
        document.querySelectorAll('.view-details').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const requestId = e.target.closest('.request-card').dataset.requestId;
                this.viewRequestDetails(requestId);
            });
        });

        document.querySelectorAll('.sign-request').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const requestId = e.target.closest('.request-card').dataset.requestId;
                this.openSignatureModal(requestId);
            });
        });
    }

    async loadMyModules() {
        const container = document.getElementById('modulesContainer');
        if (!container) return;
        
        container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><h3>Loading Your Modules...</h3></div>';
        
        try {
            const response = await fetch('/api/lecturer/my-modules');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    container.innerHTML = this.renderMyModules(data.modules);
                    return;
                }
            }
        } catch (error) {
            console.error('Error loading modules:', error);
        }
        
        // Fallback: Show empty state
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-book"></i>
                <h3>Module Information</h3>
                <p>Use the API to load your assigned modules.</p>
            </div>
        `;
    }

    renderMyModules(modules) {
        if (!modules || modules.length === 0) {
            return `
                <div class="empty-state">
                    <i class="fas fa-book"></i>
                    <h3>No Assigned Modules</h3>
                    <p>You are not currently assigned to teach any modules.</p>
                </div>
            `;
        }

        return `
            <div class="modules-grid">
                ${modules.map(module => this.renderModuleCard(module)).join('')}
            </div>
        `;
    }

    renderModuleCard(module) {
        return `
            <div class="module-card">
                <div class="module-header">
                    <h4>${module.module_code}</h4>
                    <span class="module-status">Active</span>
                </div>
                <div class="module-body">
                    <h5>${module.module_name}</h5>
                    <div class="module-stats">
                        <div class="stat">
                            <i class="fas fa-users"></i>
                            <span>${module.student_count || 0} Students</span>
                        </div>
                        <div class="stat">
                            <i class="fas fa-clock"></i>
                            <span>${module.pending_requests || 0} Pending</span>
                        </div>
                    </div>
                </div>
                <div class="module-actions">
                    <button class="btn btn-outline view-students" data-module="${module.module_code}">
                        <i class="fas fa-list"></i> View Students
                    </button>
                    <button class="btn btn-outline view-requests" data-module="${module.module_code}">
                        <i class="fas fa-tasks"></i> View Requests
                    </button>
                </div>
            </div>
        `;
    }

    attachModuleEventListeners() {
        document.querySelectorAll('.view-students').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const moduleCode = e.target.closest('.view-students').dataset.module;
                this.viewModuleStudents(moduleCode);
            });
        });

        document.querySelectorAll('.view-requests').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const moduleCode = e.target.closest('.view-requests').dataset.module;
                this.filters.module = moduleCode;
                this.switchToSection('module-requests');
                document.getElementById('moduleFilter').value = moduleCode;
                this.loadModuleRequests();
            });
        });
    }

    async loadReviewHistory() {
        const container = document.getElementById('historyContainer');
        if (!container) return;
        
        container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><h3>Loading History...</h3></div>';
        
        try {
            const response = await fetch('/api/lecturer/review-history');
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    container.innerHTML = this.renderReviewHistory(data.history);
                    this.attachHistoryEventListeners();
                    return;
                }
            }
        } catch (error) {
            console.error('Error loading history:', error);
        }
        
        // Fallback: Show empty state
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-history"></i>
                <h3>No Review History</h3>
                <p>You haven't reviewed any module requests yet.</p>
            </div>
        `;
    }

    renderReviewHistory(history) {
        if (!history || history.length === 0) {
            return `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <h3>No Review History</h3>
                    <p>You haven't reviewed any module requests yet.</p>
                </div>
            `;
        }

        return `
            <div class="history-table">
                <table>
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Module</th>
                            <th>Request Type</th>
                            <th>Status</th>
                            <th>Reviewed Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${history.map(item => this.renderHistoryRow(item)).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    renderHistoryRow(item) {
        const statusClass = this.getStatusClass(item.request_status);
        
        return `
            <tr>
                <td>
                    <div class="student-cell">
                        <strong>${item.student_first_name} ${item.student_last_name}</strong>
                        <small>${item.student_username}</small>
                    </div>
                </td>
                <td>
                    <div class="module-cell">
                        <strong>${item.module_code}</strong>
                        <small>${item.module_name}</small>
                    </div>
                </td>
                <td>
                    <span class="request-type ${item.request_type}">${item.request_type.toUpperCase()}</span>
                </td>
                <td>
                    <span class="status-badge ${statusClass}">${item.request_status.replace('_', ' ')}</span>
                </td>
                <td>${new Date(item.lecturer_signed_at).toLocaleTimeString()}</td>
                <td>
                    <button class="btn btn-sm btn-outline view-details" data-request-id="${item.request_id}">
                        <i class="fas fa-eye"></i> Details
                    </button>
                </td>
            </tr>
        `;
    }

    attachHistoryEventListeners() {
        document.querySelectorAll('.view-details').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const requestId = e.target.closest('.view-details').dataset.requestId;
                this.viewRequestDetails(requestId);
            });
        });
    }

    async viewRequestDetails(requestId) {
        try {
            const response = await fetch(`/api/lecturer/request-details/${requestId}`);
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.showRequestDetails(data.request);
                    return;
                }
            }
        } catch (error) {
            console.error('Error loading request details:', error);
        }
        
        // Fallback: Try to find request in template data
        const request = this.findRequestInTemplateData(requestId);
        if (request) {
            this.showRequestDetails(request);
        } else {
            alert('Request details not available');
        }
    }

    findRequestInTemplateData(requestId) {
        return (this.initialData.requests || []).find(req => 
            (req.request_id || req.id) == requestId
        );
    }

    showRequestDetails(request) {
        const modalBody = document.getElementById('detailsModalBody');
        const statusClass = this.getStatusClass(request.request_status);
        
        modalBody.innerHTML = `
            <div class="request-summary">
                <div class="detail-row">
                    <label>Request Time:</label>
                    <span>${new Date(request.created_at).toLocaleTimeString()}</span>
                </div>
                ${request.lecturer_signed_at ? `
                <div class="detail-row">
                    <label>Reviewed Time:</label>
                    <span>${new Date(request.lecturer_signed_at).toLocaleTimeString()}</span>
                </div>
                ` : ''}
            </div>
        `;
        
        document.getElementById('detailsModal').classList.add('active');
    }

    async openSignatureModal(requestId) {
        this.currentRequestId = requestId;
        
        try {
            const response = await fetch(`/api/lecturer/request-details/${requestId}`);
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.showSignatureModal(data.request);
                    return;
                }
            }
        } catch (error) {
            console.error('Error loading request details:', error);
        }
        
        // Fallback: Try to find request in template data
        const request = this.findRequestInTemplateData(requestId);
        if (request) {
            this.showSignatureModal(request);
        } else {
            alert('Request details not available');
        }
    }

    showSignatureModal(request) {
        const summary = document.getElementById('requestSummary');
        const statusClass = this.getStatusClass(request.request_status);
        
        summary.innerHTML = `
            <div class="detail-row">
                <label>Student:</label>
                <span><strong>${request.student_first_name || request.first_name} ${request.student_last_name || request.surname}</strong></span>
            </div>
            <div class="detail-row">
                <label>Module:</label>
                <span><strong>${request.module_code || request.subject_code}</strong> - ${request.module_name || request.subject_name}</span>
            </div>
            <div class="detail-row">
                <label>Request Type:</label>
                <span class="request-type ${request.request_type}">${request.request_type.toUpperCase()}</span>
            </div>
            <div class="detail-row">
                <label>Reason:</label>
                <span>${request.reason || 'No reason provided'}</span>
            </div>
        `;
        
        document.getElementById('signatureModal').classList.add('active');
        
        // Resize signature pad when modal opens
        setTimeout(() => {
            this.resizeSignatureCanvas();
        }, 100);
        
        if (this.signaturePad) {
            this.signaturePad.clear();
        }
    }

    closeSignatureModal() {
        document.getElementById('signatureModal').classList.remove('active');
        this.currentRequestId = null;
        document.getElementById('lecturerComment').value = '';
        
        if (this.signaturePad) {
            this.signaturePad.clear();
        }
    }

    closeDetailsModal() {
        document.getElementById('detailsModal').classList.remove('active');
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.remove('active');
        });
        this.currentRequestId = null;
        
        if (this.signaturePad) {
            this.signaturePad.clear();
        }
    }

    clearSignature() {
        if (this.signaturePad) {
            this.signaturePad.clear();
        }
    }

    async saveSignature() {
        if (!this.signaturePad || this.signaturePad.isEmpty()) {
            alert('Please provide your signature before submitting.');
            return;
        }

        if (!this.currentRequestId) {
            alert('No request selected for signing.');
            return;
        }

        try {
            const signatureData = this.signaturePad.toDataURL();
            const comment = document.getElementById('lecturerComment').value;
            
            // Add loading state
            const saveBtn = document.getElementById('saveSignature');
            const originalText = saveBtn.innerHTML;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing...';
            saveBtn.disabled = true;

            const response = await fetch('/api/lecturer/sign-request', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    request_id: this.currentRequestId,
                    signature: signatureData,
                    comment: comment
                })
            });

            const data = await response.json();
            
            // Restore button state
            saveBtn.innerHTML = originalText;
            saveBtn.disabled = false;
            
            if (data.success) {
                this.showSuccess('Request signed successfully!');
                this.closeSignatureModal();
                
                // Refresh the relevant sections
                await this.loadModuleRequests();
                await this.loadDashboardOverview();
                await this.updateNotificationBadge();
                
                // If on dashboard, refresh it too
                if (document.getElementById('dashboard').classList.contains('active')) {
                    await this.loadDashboardOverview();
                }
            } else {
                this.showError('Failed to sign request: ' + (data.message || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error signing request:', error);
            
            // Restore button state
            const saveBtn = document.getElementById('saveSignature');
            saveBtn.innerHTML = '<i class="fas fa-check"></i> Sign & Submit';
            saveBtn.disabled = false;
            
            this.showError('Error signing request. Please try again.');
        }
    }

    async viewModuleStudents(moduleCode) {
        // Implement view module students functionality
        alert(`View students for module: ${moduleCode}`);
    }

    updateModuleFilterOptions(modules) {
        const moduleFilter = document.getElementById('moduleFilter');
        if (!moduleFilter) return;
        
        // Keep the current selection
        const currentValue = moduleFilter.value;
        
        // Clear existing options except "All Modules"
        moduleFilter.innerHTML = '<option value="all">All Modules</option>';
        
        // Add module options
        if (modules && modules.length > 0) {
            modules.forEach(module => {
                const option = document.createElement('option');
                option.value = module.module_code;
                option.textContent = `${module.module_code} - ${module.module_name}`;
                moduleFilter.appendChild(option);
            });
        }
        
        // Restore selection if still valid
        if (currentValue && Array.from(moduleFilter.options).some(opt => opt.value === currentValue)) {
            moduleFilter.value = currentValue;
        }
    }

    getStatusClass(status) {
        const statusMap = {
            'pending_lecturer': 'pending',
            'pending_hod': 'pending_hod',
            'pending_admin': 'pending_admin',
            'approved_lecturer': 'approved',
            'approved_admin': 'approved',
            'rejected_lecturer': 'rejected',
            'rejected_admin': 'rejected',
            'recommended_hod': 'approved'
        };
        return statusMap[status] || 'pending';
    }

    isRequestUrgent(createdAt) {
        if (!createdAt) return false;
        const created = new Date(createdAt);
        const now = new Date();
        const diffDays = (now - created) / (1000 * 60 * 60 * 24);
        return diffDays > 2; // More than 2 days old
    }

    renderRequestsTable(requests, isCompact = false) {
        if (!requests || requests.length === 0) {
            return '<div class="empty-state"><p>No requests found</p></div>';
        }

        if (isCompact) {
            return `
                <div class="requests-grid">
                    ${requests.slice(0, 3).map(request => this.renderRequestCard(request)).join('')}
                </div>
            `;
        }

        return requests.map(request => this.renderRequestCard(request)).join('');
    }

    renderError(message) {
        return `
            <div class="error-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Error</h3>
                <p>${message}</p>
                <button class="btn btn-primary" onclick="location.reload()">
                    <i class="fas fa-redo"></i> Retry
                </button>
            </div>
        `;
    }

    showError(message) {
        // You can replace this with a more sophisticated notification system
        alert(`Error: ${message}`);
    }

    showSuccess(message) {
        // You can replace this with a more sophisticated notification system
        alert(`Success: ${message}`);
    }

    handleLogout() {
        if (confirm('Are you sure you want to logout?')) {
            window.location.href = '/logout';
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Pass template data to JavaScript
    try {
        window.userData = JSON.parse(document.getElementById('user-data')?.textContent || '{}');
        window.requestsData = JSON.parse(document.getElementById('requests-data')?.textContent || '[]');
        window.assignedModules = parseInt(document.getElementById('assigned-modules-data')?.textContent || '0');
        window.pendingCount = parseInt(document.getElementById('pending-count-data')?.textContent || '0');
    } catch (e) {
        console.error('Error parsing template data:', e);
        window.userData = {};
        window.requestsData = [];
        window.assignedModules = 0;
        window.pendingCount = 0;
    }
    
    new LecturerDashboard();
});