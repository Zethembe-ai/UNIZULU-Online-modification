// static/js/hod_dashboard.js

let modulesLoaded = false;

document.addEventListener('DOMContentLoaded', function() {
    setupEventListeners();
});

function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            if (target) {
                switchSection(target);
            }
        });
    });

    // Modal close buttons
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', function() {
            closeModals();
        });
    });

    // Cancel recommendation
    document.getElementById('cancelSignature')?.addEventListener('click', function() {
        closeModals();
    });

    // Save recommendation
    document.getElementById('saveSignature')?.addEventListener('click', function() {
        saveRecommendation();
    });

    // Close modals when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModals();
            }
        });
    });

    // Logout
    document.getElementById('logoutBtn')?.addEventListener('click', function() {
        if (confirm('Are you sure you want to logout?')) {
            window.location.href = '/logout';
        }
    });
}

function switchSection(sectionId) {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-target="${sectionId}"]`).classList.add('active');

    // Update content sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
    
    // Auto-load department modules when that section is opened
    if (sectionId === 'department-modules' && !modulesLoaded) {
        setTimeout(() => {
            loadDepartmentModules();
            modulesLoaded = true;
        }, 100);
    }
}

async function reviewRequest(requestId) {
    try {
        const response = await fetch(`/hod/get_request_details/${requestId}`);
        const requestData = await response.json();
        
        if (response.ok) {
            populateReviewModal(requestData);
            openModal('reviewModal');
        } else {
            alert('Error loading request details: ' + requestData.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error loading request details');
    }
}

function populateReviewModal(requestData) {
    const modalBody = document.getElementById('reviewModalBody');
    
    modalBody.innerHTML = `
        <div class="request-details-modal">
            <div class="detail-group">
                <h4>Student Information</h4>
                <p><strong>Name:</strong> ${requestData.student_first_name} ${requestData.student_last_name}</p>
                <p><strong>Student Number:</strong> ${requestData.username}</p>
                <p><strong>Program:</strong> ${requestData.program_code}</p>
                <p><strong>Year Level:</strong> ${requestData.year_level}</p>
            </div>
            
            <div class="detail-group">
                <h4>Module Information</h4>
                <p><strong>Module Code:</strong> ${requestData.module_code}</p>
                <p><strong>Module Name:</strong> ${requestData.module_name}</p>
                <p><strong>Request Type:</strong> <span class="request-type ${requestData.request_type.toLowerCase()}">${requestData.request_type}</span></p>
            </div>
            
            <div class="detail-group">
                <h4>Request Details</h4>
                <p><strong>Reason:</strong> ${requestData.reason || 'No reason provided'}</p>
                <p><strong>Request Date:</strong> ${new Date(requestData.created_at).toLocaleDateString()}</p>
            </div>
            
            ${requestData.lecturer_comment ? `
            <div class="detail-group">
                <h4>Lecturer Comments</h4>
                <p>${requestData.lecturer_comment}</p>
                <p><small>Signed by: ${requestData.lecturer_title || ''} ${requestData.lecturer_last_name || ''} on ${requestData.lecturer_signed_at ? new Date(requestData.lecturer_signed_at).toLocaleDateString() : 'N/A'}</small></p>
            </div>
            ` : ''}
            
            <div class="modal-actions">
                <button class="btn btn-outline" onclick="closeModals()">Close</button>
                <button class="btn btn-primary" onclick="openSignatureModal(${requestData.request_id}, '${requestData.username} - ${requestData.student_first_name} ${requestData.student_last_name}')">
                    <i class="fas fa-signature"></i> Add Recommendation
                </button>
            </div>
        </div>
    `;
}

function openSignatureModal(requestId, studentInfo) {
    document.getElementById('modalRequestDetails').innerHTML = `
        <div class="request-info-banner">
            <h4>Request: #${requestId}</h4>
            <p><strong>Student:</strong> ${studentInfo}</p>
        </div>
    `;
    
    // Store the current request ID
    document.getElementById('signatureModal').setAttribute('data-request-id', requestId);
    
    // Reset form
    document.querySelectorAll('input[name="recommendation"]').forEach(radio => {
        radio.checked = false;
    });
    document.getElementById('comments').value = '';
    
    openModal('signatureModal');
}

async function saveRecommendation() {
    const requestId = document.getElementById('signatureModal').getAttribute('data-request-id');
    const recommendation = document.querySelector('input[name="recommendation"]:checked');
    const comments = document.getElementById('comments').value;
    
    if (!recommendation) {
        alert('Please select a recommendation');
        return;
    }
    
    try {
        const response = await fetch('/hod/recommend-request/' + requestId, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                recommendation: recommendation.value,
                comment: comments
            })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            alert('Recommendation submitted successfully!');
            closeModals();
            location.reload(); // Refresh to show updated status
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error submitting recommendation');
    }
}

// Department Modules Functions
async function loadDepartmentModules() {
    const container = document.getElementById('modulesContainer');
    const statsContainer = document.getElementById('modulesStats');
    
    // Show loading state
    container.innerHTML = `
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading department modules...</p>
        </div>
    `;
    
    try {
        const response = await fetch('/hod/department-modules');
        const data = await response.json();
        
        if (response.ok && data.success) {
            displayDepartmentStats(data.stats);
            displayDepartmentModules(data.modules);
        } else {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Error Loading Modules</h3>
                    <p>${data.error || 'Failed to load department modules'}</p>
                    <button class="btn btn-primary" onclick="loadDepartmentModules()">
                        <i class="fas fa-sync-alt"></i> Try Again
                    </button>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading department modules:', error);
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Connection Error</h3>
                <p>Failed to load department modules. Please check your connection.</p>
                <button class="btn btn-primary" onclick="loadDepartmentModules()">
                    <i class="fas fa-sync-alt"></i> Try Again
                </button>
            </div>
        `;
    }
}

function displayDepartmentStats(stats) {
    const statsContainer = document.getElementById('modulesStats');
    
    statsContainer.innerHTML = `
        <div class="stat-item">
            <span class="stat-value">${stats.total_modules || 0}</span>
            <span class="stat-label">Total Modules</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${stats.total_lecturers || 0}</span>
            <span class="stat-label">Assigned Lecturers</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${stats.total_students || 0}</span>
            <span class="stat-label">Enrolled Students</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${stats.total_credits || 0}</span>
            <span class="stat-label">Total Credits</span>
        </div>
    `;
}

function displayDepartmentModules(modules) {
    const container = document.getElementById('modulesContainer');
    
    if (!modules || modules.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-book"></i>
                <h3>No Modules Found</h3>
                <p>No modules are currently offered by your department.</p>
            </div>
        `;
        return;
    }
    
    const modulesHTML = modules.map(module => `
        <div class="module-card" data-year="${module.year_level}" data-semester="${module.semester}">
            <div class="module-header">
                <div class="module-code">${module.module_code}</div>
                <div class="module-year">Year ${module.year_level}</div>
            </div>
            <div class="module-name">${module.module_name}</div>
            <div class="module-details">
                <div class="module-detail">
                    <span class="detail-label">Credits</span>
                    <span class="detail-value">${module.credits}</span>
                </div>
                <div class="module-detail">
                    <span class="detail-label">NQF Level</span>
                    <span class="detail-value">${module.nqf_level}</span>
                </div>
                <div class="module-detail">
                    <span class="detail-label">Semester</span>
                    <span class="detail-value">${module.semester}</span>
                </div>
                <div class="module-detail">
                    <span class="detail-label">Programs</span>
                    <span class="detail-value">${(module.program_codes || '').split(',').length}</span>
                </div>
            </div>
            ${module.prerequisites ? `
            <div class="module-detail">
                <span class="detail-label">Prerequisites</span>
                <span class="detail-value">${module.prerequisites}</span>
            </div>
            ` : ''}
            <div class="module-stats">
                <div class="stat-badge">
                    <span class="stat-number">${module.assigned_lecturers || 0}</span>
                    <span class="stat-text">Lecturers</span>
                </div>
                <div class="stat-badge">
                    <span class="stat-number">${module.enrolled_students || 0}</span>
                    <span class="stat-text">Students</span>
                </div>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = `<div class="modules-grid">${modulesHTML}</div>`;
}

function filterModules() {
    const yearFilter = document.getElementById('yearFilter').value;
    const semesterFilter = document.getElementById('semesterFilter').value;
    const modules = document.querySelectorAll('.module-card');
    
    modules.forEach(module => {
        const moduleYear = module.getAttribute('data-year');
        const moduleSemester = module.getAttribute('data-semester');
        
        const yearMatch = yearFilter === 'all' || moduleYear === yearFilter;
        const semesterMatch = semesterFilter === 'all' || moduleSemester === semesterFilter;
        
        if (yearMatch && semesterMatch) {
            module.style.display = 'block';
        } else {
            module.style.display = 'none';
        }
    });
}

function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
    document.body.style.overflow = 'auto';
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModals();
    }
});