let currentlyVisible = null;

function toggleSection(id) {
  const section = document.getElementById(id);

  if (currentlyVisible === id) {
    // If the clicked section is already visible, hide it
    section.style.display = 'none';
    currentlyVisible = null;
  } else {
    // Hide all sections first
    document.querySelectorAll('section').forEach(sec => {
      sec.style.display = 'none';
    });

    // Show the clicked section
    section.style.display = 'block';
    section.scrollIntoView({ behavior: 'smooth' });
    currentlyVisible = id;
  }
}

function showMessage(text, type) {
  const messageEl = document.getElementById('message');
  messageEl.textContent = text;
  messageEl.className = `message ${type}`;
  messageEl.style.display = 'block';
  
  // Hide message after 5 seconds
  setTimeout(() => {
    messageEl.style.display = 'none';
  }, 5000);
}

// Handle form submission
document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const userType = document.querySelector('input[name="userType"]:checked').value;
  const loadingEl = document.getElementById('loading');
  
  if (!username || !password) {
    showMessage('Please enter both username and password', 'error');
    return;
  }
  
  // Show loading indicator
  loadingEl.style.display = 'block';
  
  // Submit login request to Flask backend
  fetch('/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&userType=${encodeURIComponent(userType)}`
  })
  .then(response => {
    // Hide loading immediately
    loadingEl.style.display = 'none';

    const contentType = response.headers.get('content-type') || '';

    // If server returned JSON (API style), parse and handle it
    if (contentType.includes('application/json')) {
      return response.json().then(data => {
        if (data.success) {
          showMessage(data.message || 'Welcome!', 'success');
          // If server provided a redirect URL, use it, otherwise fallback to /dashboard
          const dest = data.redirect_url || '/dashboard';
          setTimeout(() => { window.location.href = dest; }, 800);
        } else {
          showMessage(data.message || 'Login failed. Please try again.', 'error');
        }
      });
    }

    // If not JSON, assume server returned HTML (possibly a redirect to dashboard).
    // If the fetch followed a redirect, response.redirected will be true and response.url will be the target.
    if (response.redirected) {
      window.location.href = response.url;
      return;
    }

    // Otherwise try to inspect the response body or show a generic error
    return response.text().then(body => {
      // Heuristic: if body contains "dashboard" path, redirect to /dashboard, else show error
      if (body && body.toLowerCase().includes('dashboard')) {
        window.location.href = '/dashboard';
      } else {
        showMessage('Login failed. Please try again.', 'error');
      }
    });
  })
  .catch(error => {
    loadingEl.style.display = 'none';
    console.error('Login error:', error);
    showMessage('Login failed. Please try again.', 'error');
  });
});

// Allow pressing Enter to submit the form
document.getElementById('password').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    document.getElementById('loginForm').dispatchEvent(new Event('submit'));
  }
});

// Forgot Password Functions
function openForgotPasswordModal() {
  document.getElementById('forgotPasswordModal').style.display = 'block';
}

function closeForgotPasswordModal() {
  document.getElementById('forgotPasswordModal').style.display = 'none';
  document.getElementById('resetEmail').value = '';
  document.getElementById('resetLoading').style.display = 'none';
}

function resetPassword() {
  const email = document.getElementById('resetEmail').value.trim();
  const loadingEl = document.getElementById('resetLoading');
  
  if (!email) {
    alert('Please enter your email address');
    return;
  }
  
  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert('Please enter a valid email address');
    return;
  }
  
  // Show loading indicator
  loadingEl.style.display = 'block';
  
  // Submit reset password request to Flask backend
  fetch('/reset-password', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `email=${encodeURIComponent(email)}`
  })
  .then(response => response.json())
  .then(data => {
    loadingEl.style.display = 'none';
    
    if (data.success) {
      alert('A new password has been sent to your email address.');
      closeForgotPasswordModal();
    } else {
      alert('Error: ' + data.message);
    }
  })
  .catch(error => {
    loadingEl.style.display = 'none';
    alert('Error resetting password. Please try again.');
  });
}

// Close modal when clicking outside of it
window.onclick = function(event) {
  const modal = document.getElementById('forgotPasswordModal');
  if (event.target == modal) {
    closeForgotPasswordModal();
  }
}

// Initialize event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const loading = document.getElementById('loading');
  const message = document.getElementById('message');

  if (!form) return;

  function showLoading(show) {
    if (!loading) return;
    loading.style.display = show ? 'block' : 'none';
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!form) return;

    message.textContent = '';
    showLoading(true);

    const formData = new FormData(form);

    try {
      const resp = await fetch(form.action || '/login', {
        method: form.method || 'POST',
        body: formData,
        credentials: 'same-origin',
        headers: {
          'X-Requested-With': 'XMLHttpRequest'
        }
      });

      const data = await resp.json();

      if (resp.ok && data && data.success) {
        // Redirect only on successful login
        window.location.href = data.redirect_url || data.redirect || '/dashboard';
      } else {
        showLoading(false);
        message.textContent = (data && data.message) ? data.message : 'Login failed. Check credentials.';
      }
    } catch (err) {
      showLoading(false);
      message.textContent = 'Network error. Try again.';
      console.error(err);
    }
  });
  
  // Add click listeners to nav buttons for better UX
  document.querySelectorAll('.nav-buttons button').forEach(button => {
    button.addEventListener('click', function() {
      // Remove active class from all buttons
      document.querySelectorAll('.nav-buttons button').forEach(btn => {
        btn.classList.remove('active');
      });
      // Add active class to clicked button
      this.classList.add('active');
    });
  });
});