-- FIXED UNIVERSITY DATABASE - SECOND SEMESTER 2025
-- Drop existing tables if they exist
DROP TABLE IF EXISTS academic_records;
DROP TABLE IF EXISTS current_semester_tracking;
DROP TABLE IF EXISTS student_yearly_progress;
DROP TABLE IF EXISTS yearly_credit_limits;
DROP TABLE IF EXISTS student_modules;
DROP TABLE IF EXISTS modification_requests;
DROP TABLE IF EXISTS module_assignments;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS lecturers;
DROP TABLE IF EXISTS hods;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS programs;
DROP TABLE IF EXISTS program_modules;

-- Create Tables
-- [All table creation statements remain exactly the same as in your original code]
-- Programs Table
CREATE TABLE programs (
    program_code VARCHAR(20) PRIMARY KEY,
    program_name VARCHAR(200) NOT NULL,
    duration_years INT NOT NULL,
    total_credits INT NOT NULL,
    faculty VARCHAR(200) NOT NULL,
    departments TEXT NOT NULL,
    degree VARCHAR(100) NOT NULL,
    majors TEXT NOT NULL,
    abbreviation VARCHAR(20) NOT NULL,
    exit_nqf_level INT NOT NULL
);

-- Program Modules Table
CREATE TABLE program_modules (
    module_code VARCHAR(20) PRIMARY KEY,
    module_name VARCHAR(200) NOT NULL,
    department VARCHAR(100) NOT NULL,
    credits INT NOT NULL,
    nqf_level INT NOT NULL,
    semester VARCHAR(20) NOT NULL,
    year_level INT NOT NULL,
    prerequisites TEXT,
    corequisites TEXT,
    program_codes TEXT NOT NULL
);

-- Students Table
CREATE TABLE students (
    username VARCHAR(20) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role VARCHAR(20) DEFAULT 'student',
    program_code VARCHAR(20) NOT NULL,
    year_level INT DEFAULT 1,
    enrollment_status VARCHAR(20) DEFAULT 'active',
    total_credits_earned INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (program_code) REFERENCES programs(program_code)
);

-- Lecturers Table
CREATE TABLE lecturers (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    title VARCHAR(20) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role VARCHAR(20) DEFAULT 'lecturer',
    department VARCHAR(100) NOT NULL,
    faculty VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- HODs Table
CREATE TABLE hods (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    title VARCHAR(20) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role VARCHAR(20) DEFAULT 'hod',
    department VARCHAR(100) NOT NULL,
    faculty VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admins Table
CREATE TABLE admins (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role VARCHAR(20) DEFAULT 'admin',
    faculty VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Yearly Credit Limits Table
CREATE TABLE yearly_credit_limits (
    year_level INT PRIMARY KEY,
    max_credits INT NOT NULL,
    description VARCHAR(100)
);

-- Student Yearly Progress Table
CREATE TABLE student_yearly_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(20) NOT NULL,
    academic_year INT NOT NULL,
    year_level INT NOT NULL,
    credits_registered INT DEFAULT 0,
    credits_earned INT DEFAULT 0,
    credits_remaining INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES students(username),
    UNIQUE(username, academic_year)
);

-- Modification Requests Table
CREATE TABLE modification_requests (
    request_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(20) NOT NULL,
    module_code VARCHAR(20) NOT NULL,
    semester VARCHAR(20),
    request_type VARCHAR(10) NOT NULL,
    reason TEXT,
    status VARCHAR(30) DEFAULT 'pending_lecturer',
    lecturer_username VARCHAR(50),
    lecturer_comment TEXT,
    lecturer_signed_at DATETIME,
    hod_username VARCHAR(50),
    hod_comment TEXT,
    hod_recommended_at DATETIME,
    admin_username VARCHAR(50),
    admin_comment TEXT,
    admin_approved_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES students(username),
    FOREIGN KEY (lecturer_username) REFERENCES lecturers(username),
    FOREIGN KEY (hod_username) REFERENCES hods(username),
    FOREIGN KEY (admin_username) REFERENCES admins(username)
);

-- Student Modules Table
CREATE TABLE student_modules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(20) NOT NULL,
    module_code VARCHAR(20) NOT NULL,
    module_name VARCHAR(200) NOT NULL,
    semester VARCHAR(20) NOT NULL,
    academic_year INT NOT NULL,
    status VARCHAR(20) DEFAULT 'registered',
    final_mark DECIMAL(5,2),
    grade VARCHAR(5),
    credits_earned INT DEFAULT 0,
    approved_request_id INTEGER,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES students(username),
    FOREIGN KEY (approved_request_id) REFERENCES modification_requests(request_id)
);

-- Module Assignments Table
CREATE TABLE module_assignments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lecturer_username VARCHAR(50) NOT NULL,
    module_code VARCHAR(20) NOT NULL,
    assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lecturer_username) REFERENCES lecturers(username),
    FOREIGN KEY (module_code) REFERENCES program_modules(module_code)
);

-- ACADEMIC RECORDS SYSTEM TABLES
-- Academic Records Table (for completed/failed/withdrawn modules)
CREATE TABLE academic_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(20) NOT NULL,
    module_code VARCHAR(20) NOT NULL,
    module_name VARCHAR(200) NOT NULL,
    semester VARCHAR(20) NOT NULL,
    academic_year INT NOT NULL,
    final_mark DECIMAL(5,2),
    grade VARCHAR(5),
    credits_earned INT DEFAULT 0,
    status VARCHAR(20) NOT NULL, -- 'Completed', 'Failed', 'Withdrawn'
    program_code VARCHAR(20) NOT NULL,
    year_level INT NOT NULL,
    completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES students(username)
);

-- Current Semester Tracking Table
CREATE TABLE current_semester_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    program_code VARCHAR(20) NOT NULL,
    current_semester VARCHAR(20) NOT NULL,
    current_academic_year INT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (program_code) REFERENCES programs(program_code)
);

-- Insert Credit Limits
INSERT INTO yearly_credit_limits (year_level, max_credits, description) VALUES
(1, 160, 'First Year Maximum Credits'),
(2, 160, 'Second Year Maximum Credits'),
(3, 160, 'Third Year Maximum Credits');

-- Insert Programs (using comma-separated values instead of JSON)
INSERT INTO programs (program_code, program_name, duration_years, total_credits, faculty, departments, degree, majors, abbreviation, exit_nqf_level) VALUES
('4BSC01', 'Applied Mathematics and Computer Science', 3, 416, 'Faculty of Science, Agriculture and Engineering', 'Mathematical Sciences,Computer Science', 'Bachelor of Science', 'Applied Mathematics,Computer Science', 'BSC', 7),
('4BSC21', 'Computer Science and Mathematics', 3, 416, 'Faculty of Science, Agriculture and Engineering', 'Computer Science,Mathematical Sciences', 'Bachelor of Science', 'Computer Science,Mathematics', 'BSC', 7),
('4BSC22', 'Computer Science and Physics', 3, 416, 'Faculty of Science, Agriculture and Engineering', 'Computer Science,Physics & Engineering', 'Bachelor of Science', 'Computer Science,Physics', 'BSC', 7);

-- Insert Program Modules (using comma-separated program codes)
INSERT INTO program_modules (module_code, module_name, department, credits, nqf_level, semester, year_level, prerequisites, corequisites, program_codes) VALUES
-- Year 1 Semester 1
('4AMT111', 'Discrete Mathematics', 'Mathematical Sciences', 16, 5, 'Semester 1', 1, '', '4MTH111', '4BSC01,4BSC21,4BSC22'),
('4MTH111', 'Calculus I', 'Mathematical Sciences', 16, 5, 'Semester 1', 1, '', '', '4BSC01,4BSC21,4BSC22'),
('4CPS111', 'Introductory Computing', 'Computer Science', 16, 5, 'Semester 1', 1, '', '', '4BSC01,4BSC21,4BSC22'),
('4PHY111', 'Classical Mechanics & Properties of Matter', 'Physics', 16, 5, 'Semester 1', 1, '', '4MTH111', '4BSC01,4BSC21,4BSC22'),
('4STT111', 'Elementary Statistics for Science Students', 'Statistics', 16, 5, 'Semester 1', 1, '', '', '4BSC01,4BSC21,4BSC22'),
('4CPS121', 'Computer Literacy I', 'Computer Science', 16, 5, 'Semester 1', 1, '', '', '4BSC01,4BSC21,4BSC22'),

-- Year 1 Semester 2
('4AMT122', 'Further Discrete Mathematics', 'Mathematical Sciences', 16, 6, 'Semester 2', 1, '', '', '4BSC01,4BSC21,4BSC22'),
('4MTH112', 'Calculus II', 'Mathematical Sciences', 16, 6, 'Semester 2', 1, '', '', '4BSC01,4BSC21,4BSC22'),
('4CPS112', 'Intro to Systems Programming', 'Computer Science', 16, 6, 'Semester 2', 1, '4CPS111', '', '4BSC01,4BSC21,4BSC22'),
('4PHY112', 'Electromagnetism, Nuclear & Modern Physics', 'Physics', 16, 6, 'Semester 2', 1, '', '', '4BSC01,4BSC21,4BSC22'),
('4STT112', 'Statistics for Science Students', 'Statistics', 16, 6, 'Semester 2', 1, '', '4MTH112', '4BSC01,4BSC21,4BSC22'),
('4CPS122', 'Computer Literacy II', 'Computer Science', 16, 6, 'Semester 2', 1, '4CPS121', '', '4BSC01,4BSC21,4BSC22'),

-- Year 2 Semester 1
('4AMT211', 'Dynamical Systems & Mathematical Modelling', 'Mathematical Sciences', 16, 6, 'Semester 1', 2, '4AMT122,4MTH112', '4MTH221', '4BSC01,4BSC21'),
('4MTH221', 'Advanced Calculus', 'Mathematical Sciences', 16, 6, 'Semester 1', 2, '4MTH111,4MTH112', '', '4BSC01,4BSC21,4BSC22'),
('4CPS211', 'Data Structures and Algorithms', 'Computer Science', 16, 6, 'Semester 1', 2, '4CPS111,4CPS112', '', '4BSC01,4BSC21,4BSC22'),
('4CPS231', 'Computer Communications & Networks', 'Computer Science', 16, 6, 'Semester 1', 2, '4CPS111', '', '4BSC01,4BSC21,4BSC22'),
('4PHY211', 'Mechanics Special Relativity & Properties of Matter', 'Physics', 16, 6, 'Semester 1', 2, '4PHY111,4PHY112,4MTH111,4MTH112', '', '4BSC22'),

-- Year 2 Semester 2
('4AMT212', 'Intro to Operations Research', 'Mathematical Sciences', 16, 6, 'Semester 2', 2, '4AMT122,4MTH112', '4MTH222', '4BSC01,4BSC21'),
('4MTH222', 'Linear Algebra & Differential Equations', 'Mathematical Sciences', 16, 6, 'Semester 2', 2, '4MTH111,4MTH112', '', '4BSC01,4BSC21,4BSC22'),
('4CPS212', 'Software Engineering', 'Computer Science', 16, 6, 'Semester 2', 2, '4CPS112', '4CPS211', '4BSC01,4BSC21,4BSC22'),
('4CPS232', 'Database Information Management I', 'Computer Science', 16, 6, 'Semester 2', 2, '4CPS111', '', '4BSC01,4BSC21,4BSC22'),
('4PHY212', 'Modern Physics, Photonics & Waves', 'Physics', 16, 6, 'Semester 2', 2, '4PHY111,4PHY112,4MTH111,4MTH112', '', '4BSC22'),
('4PHY222', 'Electromagnetism', 'Physics', 16, 6, 'Semester 2', 2, '4PHY111,4PHY112,4MTH111,4MTH112', '', '4BSC22'),

-- Year 3 Semester 1
('4AMT331', 'Tensor Analysis', 'Mathematical Sciences', 16, 7, 'Semester 1', 3, '4MTH111,4MTH112,4AMT111,4AMT122,4MTH221,4MTH222,4AMT211,4AMT212', '', '4BSC01'),
('4AMT321', 'Applied Mathematical Methods', 'Mathematical Sciences', 16, 7, 'Semester 1', 3, '4MTH111,4MTH112,4AMT111,4AMT122,4MTH221,4MTH222,4AMT211,4AMT212', '', '4BSC01'),
('4CPS311', 'Advanced Programming Techniques', 'Computer Science', 16, 7, 'Semester 1', 3, '4CPS211,4CPS212', '', '4BSC01,4BSC21,4BSC22'),
('4CPS321', 'Systems Programming (OS & Compilers)', 'Computer Science', 16, 7, 'Semester 1', 3, '4CPS211,4CPS212', '', '4BSC01,4BSC21,4BSC22'),
('4MTH311', 'Abstract Algebra', 'Mathematical Sciences', 16, 7, 'Semester 1', 3, '4MTH111,4MTH112,4MTH221,4MTH222', '', '4BSC21'),
('4MTH321', 'Real Analysis', 'Mathematical Sciences', 16, 7, 'Semester 1', 3, '4MTH111,4MTH112,4MTH221,4MTH222', '', '4BSC21'),
('4PHY311', 'Quantum and Statistical Physics', 'Physics', 16, 7, 'Semester 1', 3, '4PHY211,4PHY212', '', '4BSC22'),
('4PHY321', 'Electronic Circuits and Devices', 'Physics', 16, 7, 'Semester 1', 3, '4PHY222', '', '4BSC22'),

-- Year 3 Semester 2
('4AMT312', 'Advanced Classical Mechanics', 'Mathematical Sciences', 16, 7, 'Semester 2', 3, '4MTH111,4MTH112,4AMT111,4AMT122,4MTH221,4MTH222,4AMT211,4AMT212', '', '4BSC01'),
('4AMT322', 'Numerical Methods', 'Mathematical Sciences', 16, 7, 'Semester 2', 3, '4MTH111,4MTH112,4AMT111,4AMT122,4MTH221,4MTH222,4AMT211,4AMT212', '', '4BSC01'),
('4CPS312', 'Distributed Systems Development', 'Computer Science', 16, 7, 'Semester 2', 3, '4CPS211,4CPS212', '', '4BSC01,4BSC21,4BSC22'),
('4CPS322', 'Final Year Project', 'Computer Science', 16, 7, 'Semester 2', 3, '4CPS211,4CPS212,4CPS311,4CPS321', '', '4BSC01,4BSC21,4BSC22'),
('4MTH312', 'Graph Theory', 'Mathematical Sciences', 16, 7, 'Semester 2', 3, '4MTH111,4MTH112,4MTH221,4MTH222', '', '4BSC21'),
('4MTH322', 'Complex Analysis', 'Mathematical Sciences', 16, 7, 'Semester 2', 3, '4MTH111,4MTH112,4MTH221,4MTH222', '', '4BSC21'),
('4PHY312', 'Nuclear Physics and Applications', 'Physics', 16, 7, 'Semester 2', 3, '4PHY212', '', '4BSC22'),
('4PHY322', 'Solid State Physics & Material Science', 'Physics', 16, 7, 'Semester 2', 3, '4PHY211,4PHY212', '', '4BSC22');

-- Insert Students
INSERT INTO students (username, password, email, first_name, last_name, role, program_code, year_level, enrollment_status, total_credits_earned) VALUES
-- First Year Students (2025 intake)
('202500001', 'Pass@20251', '202500001@stu.unizulu.ac.za', 'James', 'Khumalo', 'student', '4BSC01', 1, 'active', 0),
('202500002', 'Pass@20252', '202500002@stu.unizulu.ac.za', 'Sarah', 'Ndlovu', 'student', '4BSC21', 1, 'active', 0),
('202500003', 'Pass@20253', '202500003@stu.unizulu.ac.za', 'David', 'Mbeki', 'student', '4BSC22', 1, 'active', 0),
('202500004', 'Pass@20254', '202500004@stu.unizulu.ac.za', 'Lisa', 'Zulu', 'student', '4BSC01', 1, 'active', 0),
('202500005', 'Pass@20255', '202500005@stu.unizulu.ac.za', 'Mike', 'Dlamini', 'student', '4BSC21', 1, 'active', 0),
('202500006', 'Pass@20256', '202500006@stu.unizulu.ac.za', 'Grace', 'Mthembu', 'student', '4BSC22', 1, 'active', 0),
('202500007', 'Pass@20257', '202500007@stu.unizulu.ac.za', 'Brian', 'Ngcobo', 'student', '4BSC01', 1, 'active', 0),
('202500008', 'Pass@20258', '202500008@stu.unizulu.ac.za', 'Tina', 'Molefe', 'student', '4BSC21', 1, 'active', 0),
('202500009', 'Pass@20259', '202500009@stu.unizulu.ac.za', 'Kevin', 'Shabalala', 'student', '4BSC22', 1, 'active', 0),
('202500010', 'Pass@202510', '202500010@stu.unizulu.ac.za', 'Amy', 'Pillay', 'student', '4BSC01', 1, 'active', 0),

-- Second Year Students (2024 intake)
('202400001', 'Pass@20241', '202400001@stu.unizulu.ac.za', 'Thabo', 'Mokoena', 'student', '4BSC01', 2, 'active', 96),
('202400002', 'Pass@20242', '202400002@stu.unizulu.ac.za', 'Precious', 'Mbatha', 'student', '4BSC21', 2, 'active', 96),
('202400003', 'Pass@20243', '202400003@stu.unizulu.ac.za', 'Sipho', 'Maduna', 'student', '4BSC22', 2, 'active', 96),
('202400004', 'Pass@20244', '202400004@stu.unizulu.ac.za', 'Karabo', 'Pillay', 'student', '4BSC01', 2, 'active', 96),
('202400005', 'Pass@20245', '202400005@stu.unizulu.ac.za', 'Tebogo', 'Raman', 'student', '4BSC21', 2, 'active', 96),
('202400006', 'Pass@20246', '202400006@stu.unizulu.ac.za', 'Amanda', 'Cele', 'student', '4BSC22', 2, 'active', 96),

-- Third Year Students (2023 intake)
('202300001', 'Pass@20231', '202300001@stu.unizulu.ac.za', 'Nomvelo', 'Shongwe', 'student', '4BSC01', 3, 'active', 192),
('202300002', 'Pass@20232', '202300002@stu.unizulu.ac.za', 'Xolani', 'Mnguni', 'student', '4BSC21', 3, 'active', 192),
('202300003', 'Pass@20233', '202300003@stu.unizulu.ac.za', 'Ashley', 'Maseko', 'student', '4BSC22', 3, 'active', 192),
('202300004', 'Pass@20234', '202300004@stu.unizulu.ac.za', 'Keenan', 'Govender', 'student', '4BSC01', 3, 'active', 192),

-- Students with specific academic issues
('202293688', 'Mzet@51', '202293688@stu.unizulu.ac.za', 'Zethembe', 'Gumede', 'student', '4BSC01', 3, 'active', 176),
('202294632', 'Luxolo@12', '202294632@stu.unizulu.ac.za', 'Luxolo', 'Mkhize', 'student', '4BSC21', 3, 'active', 176),
('202294368', 'Samu@22', '202294368@stu.unizulu.ac.za', 'Samukelisiwe', 'Jali', 'student', '4BSC22', 3, 'active', 176),
('230012566', 'Siyab@23', '230012566@stu.unizulu.ac.za', 'Siyabuswa', 'Mdletshe', 'student', '4BSC22', 2, 'active', 80);

-- Insert Lecturers
INSERT INTO lecturers (username, password, email, title, last_name, role, department, faculty) VALUES
('lecturer.cs1', 'XcZv2bNm', 'lecturer.cs1@unizulu.ac.za', 'Dr.', 'Brown', 'lecturer', 'Computer Science', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.cs2', 'PgHk8tRs', 'lecturer.cs2@unizulu.ac.za', 'Prof.', 'Taylor', 'lecturer', 'Computer Science', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.cs3', 'LqWf4dJp', 'lecturer.cs3@unizulu.ac.za', 'Ms.', 'Clark', 'lecturer', 'Computer Science', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.math1', 'MnBv6zKt', 'lecturer.math1@unizulu.ac.za', 'Mr.', 'Lewis', 'lecturer', 'Mathematical Sciences', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.math2', 'RtSy7uVw', 'lecturer.math2@unizulu.ac.za', 'Dr.', 'Wilson', 'lecturer', 'Mathematical Sciences', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.math3', 'KjHf9dLs', 'lecturer.math3@unizulu.ac.za', 'Prof.', 'Anderson', 'lecturer', 'Mathematical Sciences', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.phy1', 'XzAb3cDe', 'lecturer.phy1@unizulu.ac.za', 'Prof.', 'Martin', 'lecturer', 'Physics', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.phy2', 'WqRt5yPn', 'lecturer.phy2@unizulu.ac.za', 'Dr.', 'Roberts', 'lecturer', 'Physics', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.stat1', 'YtBv4nKm', 'lecturer.stat1@unizulu.ac.za', 'Dr.', 'Adams', 'lecturer', 'Statistics', 'Faculty of Science, Agriculture and Engineering'),
('lecturer.stat2', 'VbNm7jKt', 'lecturer.stat2@unizulu.ac.za', 'Ms.', 'Davis', 'lecturer', 'Statistics', 'Faculty of Science, Agriculture and Engineering');

-- Insert HODs
INSERT INTO hods (username, password, email, title, last_name, role, department, faculty) VALUES
('hod.cs', 'FdMw3sPq', 'hod.cs@unizulu.ac.za', 'Professor', 'Davis', 'hod', 'Computer Science', 'Faculty of Science, Agriculture and Engineering'),
('hod.math', 'LpQr0sTu', 'hod.math@unizulu.ac.za', 'Prof.', 'Anderson', 'hod', 'Mathematical Sciences', 'Faculty of Science, Agriculture and Engineering'),
('hod.phy', 'KjMp9rSt', 'hod.phy@unizulu.ac.za', 'Dr.', 'Johnson', 'hod', 'Physics', 'Faculty of Science, Agriculture and Engineering'),
('hod.stat', 'TgHn8vBq', 'hod.stat@unizulu.ac.za', 'Dr.', 'Williams', 'hod', 'Statistics', 'Faculty of Science, Agriculture and Engineering');

-- Insert Admins
INSERT INTO admins (username, password, email, first_name, last_name, role, faculty) VALUES
('admin1', 'KgTp7zRm', 'admin1@unizulu.ac.za', 'John', 'Smith', 'admin', 'Faculty of Science, Agriculture and Engineering'),
('admin2', 'VqBx9nLk', 'admin2@unizulu.ac.za', 'Mary', 'Johnson', 'admin', 'Faculty of Science, Agriculture and Engineering'),
('admin3', 'YhNp8qRt', 'admin3@unizulu.ac.za', 'Robert', 'Wilson', 'admin', 'Faculty of Science, Agriculture and Engineering');

-- Insert Module Assignments
INSERT INTO module_assignments (lecturer_username, module_code) VALUES
-- Computer Science modules
('lecturer.cs1', '4CPS111'), ('lecturer.cs1', '4CPS211'),
('lecturer.cs2', '4CPS112'), ('lecturer.cs2', '4CPS212'),
('lecturer.cs3', '4CPS231'), ('lecturer.cs3', '4CPS232'),
('lecturer.cs1', '4CPS311'), ('lecturer.cs2', '4CPS321'),
('lecturer.cs3', '4CPS312'), ('lecturer.cs1', '4CPS322'),
-- New Computer Literacy modules
('lecturer.cs1', '4CPS121'),
('lecturer.cs2', '4CPS122'),
-- Mathematical Sciences modules
('lecturer.math1', '4AMT111'), ('lecturer.math1', '4AMT331'),
('lecturer.math2', '4MTH111'), ('lecturer.math2', '4AMT312'),
('lecturer.math3', '4AMT122'), ('lecturer.math3', '4AMT321'),
('lecturer.math1', '4MTH112'), ('lecturer.math2', '4AMT211'),
('lecturer.math3', '4MTH221'), ('lecturer.math1', '4MTH222'),
('lecturer.math2', '4AMT212'), ('lecturer.math3', '4AMT322'),
('lecturer.math1', '4MTH311'), ('lecturer.math2', '4MTH321'),
('lecturer.math3', '4MTH312'), ('lecturer.math1', '4MTH322'),
-- Physics modules
('lecturer.phy1', '4PHY111'), ('lecturer.phy1', '4PHY112'),
('lecturer.phy2', '4PHY211'), ('lecturer.phy2', '4PHY212'),
('lecturer.phy1', '4PHY311'), ('lecturer.phy2', '4PHY321'),
('lecturer.phy1', '4PHY312'), ('lecturer.phy2', '4PHY322'),
('lecturer.phy1', '4PHY222'),
-- Statistics modules
('lecturer.stat1', '4STT111'),
('lecturer.stat2', '4STT112');

-- =============================================================================
-- INITIALIZE ACADEMIC RECORDS SYSTEM
-- =============================================================================

-- Initialize Current Semester Tracking
INSERT INTO current_semester_tracking (program_code, current_semester, current_academic_year) VALUES
('4BSC01', '2', 2025),
('4BSC21', '2', 2025),
('4BSC22', '2', 2025);

-- =============================================================================
-- COMPREHENSIVE ACADEMIC HISTORY FOR ALL STUDENTS WITH COMPLETE RECORDS
-- =============================================================================

-- Clear existing student modules to start fresh
DELETE FROM student_modules;

-- ZETHEMBE GUMEDE (202293688) - 4BSC01 - Complete 3-year history
-- CHANGED: Removed computer modules for third year semester 2
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2023
('202293688', '4AMT111', 'Discrete Mathematics', '1', 2023, 'completed', 65, 'C+', 16),
('202293688', '4MTH111', 'Calculus I', '1', 2023, 'completed', 71, 'B', 16),
('202293688', '4CPS111', 'Introductory Computing', '1', 2023, 'completed', 48, 'F', 0),
('202293688', '4CPS121', 'Computer Literacy I', '1', 2023, 'completed', 69, 'C+', 16),
('202293688', '4STT111', 'Elementary Statistics for Science Students', '1', 2023, 'completed', 73, 'B', 16),

('202293688', '4AMT122', 'Further Discrete Mathematics', '2', 2023, 'completed', 67, 'C+', 16),
('202293688', '4MTH112', 'Calculus II', '2', 2023, 'completed', 62, 'C+', 16),
('202293688', '4CPS112', 'Intro to Systems Programming', '2', 2023, 'completed', 52, 'D', 16),
('202293688', '4CPS122', 'Computer Literacy II', '2', 2023, 'completed', 64, 'C+', 16),
('202293688', '4STT112', 'Statistics for Science Students', '2', 2023, 'completed', 70, 'B', 16),

-- YEAR 2 - 2024
('202293688', '4AMT211', 'Dynamical Systems & Mathematical Modelling', '1', 2024, 'completed', 72, 'B', 16),
('202293688', '4MTH221', 'Advanced Calculus', '1', 2024, 'completed', 68, 'C+', 16),
('202293688', '4CPS111', 'Introductory Computing', '1', 2024, 'completed', 65, 'C+', 16), -- Repeated
('202293688', '4CPS231', 'Computer Communications & Networks', '1', 2024, 'completed', 78, 'B+', 16),

('202293688', '4AMT212', 'Intro to Operations Research', '2', 2024, 'completed', 82, 'A', 16),
('202293688', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2024, 'completed', 58, 'D+', 16),
('202293688', '4CPS212', 'Software Engineering', '2', 2024, 'completed', 42, 'F', 0),
('202293688', '4CPS232', 'Database Information Management I', '2', 2024, 'completed', 75, 'B+', 16),

-- YEAR 3 - 2025 Semester 1 - COMPLETED
('202293688', '4AMT321', 'Applied Mathematical Methods', '1', 2025, 'completed', 65, 'C+', 16),
('202293688', '4AMT331', 'Tensor Analysis', '1', 2025, 'completed', 65, 'C+', 16),
('202293688', '4CPS212', 'Data Structures and Algorithms', '1', 2025, 'completed', 65, 'C+', 16), -- Repeated

-- YEAR 3 - 2025 Semester 2 - CHANGED: Removed computer modules, only keeping math modules - NOW REGISTERED (NO MARKS)
('202293688', '4AMT322', 'Numerical Methods', '2', 2025, 'registered', NULL, NULL, 0),
('202293688', '4AMT312', 'Advanced Classical Mechanics', '2', 2025, 'registered', NULL, NULL, 0);
-- Removed: 4CPS312 and 4CPS322 computer modules

-- LUXOLO MKHIZE (202294632) - 4BSC21 - Complete 3-year history
-- CHANGED: Added 4PHY112 to third year second semester
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2023
('202294632', '4AMT111', 'Discrete Mathematics', '1', 2023, 'completed', 68, 'C+', 16),
('202294632', '4MTH111', 'Calculus I', '1', 2023, 'completed', 72, 'B', 16),
('202294632', '4CPS111', 'Introductory Computing', '1', 2023, 'completed', 65, 'C+', 16),
('202294632', '4CPS121', 'Computer Literacy I', '1', 2023, 'completed', 58, 'D+', 16),
('202294632', '4STT111', 'Elementary Statistics for Science Students', '1', 2023, 'completed', 71, 'B', 16),

('202294632', '4AMT122', 'Further Discrete Mathematics', '2', 2023, 'completed', 70, 'B', 16),
('202294632', '4MTH112', 'Calculus II', '2', 2023, 'completed', 66, 'C+', 16),
('202294632', '4CPS112', 'Intro to Systems Programming', '2', 2023, 'completed', 61, 'C+', 16),
('202294632', '4CPS122', 'Computer Literacy II', '2', 2023, 'completed', 55, 'D+', 16),
('202294632', '4STT112', 'Statistics for Science Students', '2', 2023, 'completed', 73, 'B', 16),

-- YEAR 2 - 2024
('202294632', '4AMT211', 'Dynamical Systems & Mathematical Modelling', '1', 2024, 'completed', 65, 'C+', 16),
('202294632', '4MTH221', 'Advanced Calculus', '1', 2024, 'completed', 62, 'C+', 16),
('202294632', '4CPS211', 'Data Structures and Algorithms', '1', 2024, 'completed', 58, 'D+', 16),
('202294632', '4CPS231', 'Computer Communications & Networks', '1', 2024, 'completed', 71, 'B', 16),

('202294632', '4AMT212', 'Intro to Operations Research', '2', 2024, 'completed', 68, 'C+', 16),
('202294632', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2024, 'completed', 59, 'D+', 16),
('202294632', '4CPS212', 'Software Engineering', '2', 2024, 'completed', 52, 'D', 16),
('202294632', '4CPS232', 'Database Information Management I', '2', 2024, 'completed', 69, 'C+', 16),

-- YEAR 3 - 2025 Semester 1 - COMPLETED
('202294632', '4CPS311', 'Advanced Programming Techniques', '1', 2025, 'completed', 62, 'C+', 16),
('202294632', '4CPS321', 'Systems Programming (OS & Compilers)', '1', 2025, 'completed', 58, 'D+', 16),
('202294632', '4MTH311', 'Abstract Algebra', '1', 2025, 'completed', 65, 'C+', 16),
('202294632', '4MTH321', 'Real Analysis', '1', 2025, 'completed', 61, 'C+', 16),

-- YEAR 3 - 2025 Semester 2 - CHANGED: Added 4PHY112 - NOW REGISTERED (NO MARKS)
('202294632', '4MTH312', 'Graph Theory', '2', 2025, 'registered', NULL, NULL, 0),
('202294632', '4MTH322', 'Complex Analysis', '2', 2025, 'registered', NULL, NULL, 0),
('202294632', '4CPS312', 'Distributed Systems Development', '2', 2025, 'registered', NULL, NULL, 0),
('202294632', '4PHY112', 'Electromagnetism, Nuclear & Modern Physics', '2', 2025, 'registered', NULL, NULL, 0);

-- SAMUKELISIWE JALI (202294368) - 4BSC22 - Complete 3-year history
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2023
('202294368', '4AMT111', 'Discrete Mathematics', '1', 2023, 'completed', 72, 'B', 16),
('202294368', '4MTH111', 'Calculus I', '1', 2023, 'completed', 75, 'B+', 16),
('202294368', '4CPS111', 'Introductory Computing', '1', 2023, 'completed', 68, 'C+', 16),
('202294368', '4CPS121', 'Computer Literacy I', '1', 2023, 'completed', 71, 'B', 16),
('202294368', '4PHY111', 'Classical Mechanics & Properties of Matter', '1', 2023, 'completed', 79, 'B+', 16),

('202294368', '4AMT122', 'Further Discrete Mathematics', '2', 2023, 'completed', 74, 'B', 16),
('202294368', '4MTH112', 'Calculus II', '2', 2023, 'completed', 70, 'B', 16),
('202294368', '4CPS112', 'Intro to Systems Programming', '2', 2023, 'completed', 65, 'C+', 16),
('202294368', '4CPS122', 'Computer Literacy II', '2', 2023, 'completed', 69, 'C+', 16),
('202294368', '4PHY112', 'Electromagnetism, Nuclear & Modern Physics', '2', 2023, 'completed', 81, 'A', 16),


-- YEAR 2 - 2024
('202294368', '4PHY211', 'Mechanics Special Relativity & Properties of Matter', '1', 2024, 'completed', 82, 'A', 16),
('202294368', '4MTH221', 'Advanced Calculus', '1', 2024, 'completed', 78, 'B+', 16),
('202294368', '4CPS211', 'Data Structures and Algorithms', '1', 2024, 'completed', 65, 'C+', 16),
('202294368', '4CPS231', 'Computer Communications & Networks', '1', 2024, 'completed', 71, 'B', 16),

('202294368', '4PHY212', 'Modern Physics, Photonics & Waves', '2', 2024, 'completed', 85, 'A', 16),
('202294368', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2024, 'completed', 68, 'C+', 16),
('202294368', '4CPS212', 'Software Engineering', '2', 2024, 'completed', 47, 'F', 0),
('202294368', '4PHY222', 'Electromagnetism', '2', 2024, 'completed', 74, 'B', 16),

-- YEAR 3 - 2025 Semester 1 - COMPLETED
('202294368', '4PHY311', 'Quantum and Statistical Physics', '1', 2025, 'completed', 79, 'B+', 16),
('202294368', '4PHY321', 'Electronic Circuits and Devices', '1', 2025, 'completed', 75, 'B+', 16),
('202294368', '4CPS311', 'Advanced Programming Techniques', '1', 2025, 'completed', 68, 'C+', 16),
('202294368', '4CPS321', 'Systems Programming (OS & Compilers)', '1', 2025, 'completed', 65, 'C+', 16),

-- YEAR 3 - 2025 Semester 2 - REGISTERED (NO MARKS)
('202294368', '4PHY312', 'Nuclear Physics and Applications', '2', 2025, 'registered', NULL, NULL, 0),
('202294368', '4PHY322', 'Solid State Physics & Material Science', '2', 2025, 'registered', NULL, NULL, 0),
('202294368', '4CPS312', 'Distributed Systems Development', '2', 2025, 'registered', NULL, NULL, 0),
('202294368', '4CPS322', 'Final Year Project', '2', 2025, 'registered', NULL, NULL, 0);

-- SIYABUSWA MDLETSHE (230012566) - 4BSC22 - Complete 2-year history (FIXED)
-- CHANGED: Removed 1 module from second semester second year
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2024
('230012566', '4AMT111', 'Discrete Mathematics', '1', 2024, 'completed', 72, 'B', 16),
('230012566', '4MTH111', 'Calculus I', '1', 2024, 'completed', 68, 'C+', 16),
('230012566', '4CPS111', 'Introductory Computing', '1', 2024, 'completed', 65, 'C+', 16),
('230012566', '4CPS121', 'Computer Literacy I', '1', 2024, 'completed', 71, 'B', 16),
('230012566', '4STT111', 'Elementary Statistics for Science Students', '1', 2024, 'completed', 69, 'C+', 16),

('230012566', '4AMT122', 'Further Discrete Mathematics', '2', 2024, 'completed', 74, 'B', 16),
('230012566', '4MTH112', 'Calculus II', '2', 2024, 'completed', 70, 'B', 16),
('230012566', '4CPS112', 'Intro to Systems Programming', '2', 2024, 'completed', 62, 'C+', 16),
('230012566', '4CPS122', 'Computer Literacy II', '2', 2024, 'completed', 67, 'C+', 16),
('230012566', '4STT112', 'Statistics for Science Students', '2', 2024, 'completed', 73, 'B', 16),

-- YEAR 2 - 2025 Semester 1 - COMPLETED
('230012566', '4PHY211', 'Mechanics Special Relativity & Properties of Matter', '1', 2025, 'completed', 75, 'B+', 16),
('230012566', '4PHY222', 'Electromagnetism', '1', 2025, 'completed', 82, 'A', 16),
('230012566', '4MTH221', 'Advanced Calculus', '1', 2025, 'completed', 72, 'B', 16),
('230012566', '4CPS211', 'Data Structures and Algorithms', '1', 2025, 'completed', 68, 'C+', 16),
('230012566', '4CPS231', 'Computer Communications & Networks', '1', 2025, 'completed', 81, 'A', 16),

-- YEAR 2 - 2025 Semester 2 - CHANGED: Removed 1 module (keeping only 3 instead of 4) - NOW REGISTERED (NO MARKS)
('230012566', '4PHY212', 'Modern Physics, Photonics & Waves', '2', 2025, 'registered', NULL, NULL, 0),
('230012566', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2025, 'registered', NULL, NULL, 0),
('230012566', '4CPS212', 'Software Engineering', '2', 2025, 'registered', NULL, NULL, 0);
-- Removed: 4CPS232 module

-- NOMVELO SHONGWE (202300001) - 4BSC01 - Complete 3-year history
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2023
('202300001', '4AMT111', 'Discrete Mathematics', '1', 2023, 'completed', 72, 'B', 16),
('202300001', '4MTH111', 'Calculus I', '1', 2023, 'completed', 68, 'C+', 16),
('202300001', '4CPS111', 'Introductory Computing', '1', 2023, 'completed', 65, 'C+', 16),
('202300001', '4CPS121', 'Computer Literacy I', '1', 2023, 'completed', 71, 'B', 16),
('202300001', '4STT111', 'Elementary Statistics for Science Students', '1', 2023, 'completed', 69, 'C+', 16),

('202300001', '4AMT122', 'Further Discrete Mathematics', '2', 2023, 'completed', 74, 'B', 16),
('202300001', '4MTH112', 'Calculus II', '2', 2023, 'completed', 70, 'B', 16),
('202300001', '4CPS112', 'Intro to Systems Programming', '2', 2023, 'completed', 62, 'C+', 16),
('202300001', '4CPS122', 'Computer Literacy II', '2', 2023, 'completed', 67, 'C+', 16),
('202300001', '4STT112', 'Statistics for Science Students', '2', 2023, 'completed', 73, 'B', 16),

-- YEAR 2 - 2024
('202300001', '4AMT211', 'Dynamical Systems & Mathematical Modelling', '1', 2024, 'completed', 75, 'B+', 16),
('202300001', '4MTH221', 'Advanced Calculus', '1', 2024, 'completed', 72, 'B', 16),
('202300001', '4CPS211', 'Data Structures and Algorithms', '1', 2024, 'completed', 68, 'C+', 16),
('202300001', '4CPS231', 'Computer Communications & Networks', '1', 2024, 'completed', 81, 'A', 16),

('202300001', '4AMT212', 'Intro to Operations Research', '2', 2024, 'completed', 79, 'B+', 16),
('202300001', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2024, 'completed', 74, 'B', 16),
('202300001', '4CPS212', 'Software Engineering', '2', 2024, 'completed', 45, 'F', 0),
('202300001', '4CPS232', 'Database Information Management I', '2', 2024, 'completed', 76, 'B+', 16),

-- YEAR 3 - 2025 Semester 1 - COMPLETED
('202300001', '4AMT321', 'Applied Mathematical Methods', '1', 2025, 'completed', 78, 'B+', 16),
('202300001', '4AMT331', 'Tensor Analysis', '1', 2025, 'completed', 82, 'A', 16),
('202300001', '4CPS311', 'Advanced Programming Techniques', '1', 2025, 'completed', 85, 'A', 16),
('202300001', '4CPS321', 'Systems Programming (OS & Compilers)', '1', 2025, 'completed', 79, 'B+', 16),

-- YEAR 3 - 2025 Semester 2 - REGISTERED (NO MARKS)
('202300001', '4AMT312', 'Advanced Classical Mechanics', '2', 2025, 'registered', NULL, NULL, 0),
('202300001', '4AMT322', 'Numerical Methods', '2', 2025, 'registered', NULL, NULL, 0),
('202300001', '4CPS312', 'Distributed Systems Development', '2', 2025, 'registered', NULL, NULL, 0),
('202300001', '4CPS322', 'Final Year Project', '2', 2025, 'registered', NULL, NULL, 0);

-- XOLANI MGUNI (202300002) - 4BSC21 - Complete 3-year history
-- CHANGED: Added 4AMT322 in second semester third year
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2023
('202300002', '4AMT111', 'Discrete Mathematics', '1', 2023, 'completed', 89, 'A', 16),
('202300002', '4MTH111', 'Calculus I', '1', 2023, 'completed', 92, 'A', 16),
('202300002', '4CPS111', 'Introductory Computing', '1', 2023, 'completed', 88, 'A', 16),
('202300002', '4CPS121', 'Computer Literacy I', '1', 2023, 'completed', 90, 'A', 16),
('202300002', '4STT111', 'Elementary Statistics for Science Students', '1', 2023, 'completed', 85, 'A', 16),

('202300002', '4AMT122', 'Further Discrete Mathematics', '2', 2023, 'completed', 87, 'A', 16),
('202300002', '4MTH112', 'Calculus II', '2', 2023, 'completed', 91, 'A', 16),
('202300002', '4CPS112', 'Intro to Systems Programming', '2', 2023, 'completed', 89, 'A', 16),
('202300002', '4CPS122', 'Computer Literacy II', '2', 2023, 'completed', 88, 'A', 16),
('202300002', '4STT112', 'Statistics for Science Students', '2', 2023, 'completed', 84, 'A', 16),

-- YEAR 2 - 2024
('202300002', '4AMT211', 'Dynamical Systems & Mathematical Modelling', '1', 2024, 'completed', 84, 'A', 16),
('202300002', '4MTH221', 'Advanced Calculus', '1', 2024, 'completed', 89, 'A', 16),
('202300002', '4CPS211', 'Data Structures and Algorithms', '1', 2024, 'completed', 91, 'A', 16),
('202300002', '4CPS231', 'Computer Communications & Networks', '1', 2024, 'completed', 87, 'A', 16),

('202300002', '4AMT212', 'Intro to Operations Research', '2', 2024, 'completed', 83, 'A', 16),
('202300002', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2024, 'completed', 88, 'A', 16),
('202300002', '4CPS212', 'Software Engineering', '2', 2024, 'completed', 90, 'A', 16),
('202300002', '4CPS232', 'Database Information Management I', '2', 2024, 'completed', 86, 'A', 16),

-- YEAR 3 - 2025 Semester 1 - COMPLETED
('202300002', '4CPS311', 'Advanced Programming Techniques', '1', 2025, 'completed', 88, 'A', 16),
('202300002', '4CPS321', 'Systems Programming (OS & Compilers)', '1', 2025, 'completed', 92, 'A', 16),
('202300002', '4MTH311', 'Abstract Algebra', '1', 2025, 'completed', 85, 'A', 16),
('202300002', '4MTH321', 'Real Analysis', '1', 2025, 'completed', 79, 'B+', 16),

-- YEAR 3 - 2025 Semester 2 - CHANGED: Added 4AMT322 - NOW REGISTERED (NO MARKS)
('202300002', '4MTH312', 'Graph Theory', '2', 2025, 'registered', NULL, NULL, 0),
('202300002', '4MTH322', 'Complex Analysis', '2', 2025, 'registered', NULL, NULL, 0),
('202300002', '4CPS312', 'Distributed Systems Development', '2', 2025, 'registered', NULL, NULL, 0),
('202300002', '4AMT322', 'Numerical Methods', '2', 2025, 'registered', NULL, NULL, 0);

-- ASHLEY MASEKO (202300003) - 4BSC22 - Complete 3-year history
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2023
('202300003', '4AMT111', 'Discrete Mathematics', '1', 2023, 'completed', 68, 'C+', 16),
('202300003', '4MTH111', 'Calculus I', '1', 2023, 'completed', 72, 'B', 16),
('202300003', '4CPS111', 'Introductory Computing', '1', 2023, 'completed', 65, 'C+', 16),
('202300003', '4CPS121', 'Computer Literacy I', '1', 2023, 'completed', 69, 'C+', 16),
('202300003', '4PHY111', 'Classical Mechanics & Properties of Matter', '1', 2023, 'completed', 81, 'A', 16),
('202300003', '4STT111', 'Elementary Statistics for Science Students', '1', 2023, 'completed', 71, 'B', 16),

('202300003', '4AMT122', 'Further Discrete Mathematics', '2', 2023, 'completed', 71, 'B', 16),
('202300003', '4MTH112', 'Calculus II', '2', 2023, 'completed', 74, 'B', 16),
('202300003', '4CPS112', 'Intro to Systems Programming', '2', 2023, 'completed', 62, 'C+', 16),
('202300003', '4CPS122', 'Computer Literacy II', '2', 2023, 'completed', 70, 'B', 16),
('202300003', '4PHY112', 'Electromagnetism, Nuclear & Modern Physics', '2', 2023, 'completed', 83, 'A', 16),
('202300003', '4STT112', 'Statistics for Science Students', '2', 2023, 'completed', 73, 'B', 16),

-- YEAR 2 - 2024
('202300003', '4PHY211', 'Mechanics Special Relativity & Properties of Matter', '1', 2024, 'completed', 85, 'A', 16),
('202300003', '4PHY222', 'Electromagnetism', '1', 2024, 'completed', 88, 'A', 16),
('202300003', '4MTH221', 'Advanced Calculus', '1', 2024, 'completed', 78, 'B+', 16),
('202300003', '4CPS211', 'Data Structures and Algorithms', '1', 2024, 'completed', 68, 'C+', 16),
('202300003', '4CPS231', 'Computer Communications & Networks', '1', 2024, 'completed', 74, 'B', 16),

('202300003', '4PHY212', 'Modern Physics, Photonics & Waves', '2', 2024, 'completed', 79, 'B+', 16),
('202300003', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2024, 'completed', 65, 'C+', 16),
('202300003', '4CPS212', 'Software Engineering', '2', 2024, 'completed', 71, 'B', 16),
('202300003', '4CPS232', 'Database Information Management I', '2', 2024, 'completed', 76, 'B+', 16),

-- YEAR 3 - 2025 Semester 1 - COMPLETED
('202300003', '4PHY311', 'Quantum and Statistical Physics', '1', 2025, 'completed', 82, 'A', 16),
('202300003', '4PHY321', 'Electronic Circuits and Devices', '1', 2025, 'completed', 78, 'B+', 16),
('202300003', '4CPS311', 'Advanced Programming Techniques', '1', 2025, 'completed', 75, 'B+', 16),
('202300003', '4CPS321', 'Systems Programming (OS & Compilers)', '1', 2025, 'completed', 72, 'B', 16),

-- YEAR 3 - 2025 Semester 2 - REGISTERED (NO MARKS)
('202300003', '4PHY312', 'Nuclear Physics and Applications', '2', 2025, 'registered', NULL, NULL, 0),
('202300003', '4PHY322', 'Solid State Physics & Material Science', '2', 2025, 'registered', NULL, NULL, 0),
('202300003', '4CPS312', 'Distributed Systems Development', '2', 2025, 'registered', NULL, NULL, 0),
('202300003', '4CPS322', 'Final Year Project', '2', 2025, 'registered', NULL, NULL, 0);

-- KEENAN GOVENDER (202300004) - 4BSC01 - Complete 3-year history
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2023
('202300004', '4AMT111', 'Discrete Mathematics', '1', 2023, 'completed', 75, 'B+', 16),
('202300004', '4MTH111', 'Calculus I', '1', 2023, 'completed', 80, 'A', 16),
('202300004', '4CPS111', 'Introductory Computing', '1', 2023, 'completed', 78, 'B+', 16),
('202300004', '4CPS121', 'Computer Literacy I', '1', 2023, 'completed', 82, 'A', 16),
('202300004', '4STT111', 'Elementary Statistics for Science Students', '1', 2023, 'completed', 76, 'B+', 16),

('202300004', '4AMT122', 'Further Discrete Mathematics', '2', 2023, 'completed', 79, 'B+', 16),
('202300004', '4MTH112', 'Calculus II', '2', 2023, 'completed', 81, 'A', 16),
('202300004', '4CPS112', 'Intro to Systems Programming', '2', 2023, 'completed', 74, 'B', 16),
('202300004', '4CPS122', 'Computer Literacy II', '2', 2023, 'completed', 77, 'B+', 16),
('202300004', '4STT112', 'Statistics for Science Students', '2', 2023, 'completed', 80, 'A', 16),

-- YEAR 2 - 2024
('202300004', '4AMT211', 'Dynamical Systems & Mathematical Modelling', '1', 2024, 'completed', 82, 'A', 16),
('202300004', '4MTH221', 'Advanced Calculus', '1', 2024, 'completed', 85, 'A', 16),
('202300004', '4CPS211', 'Data Structures and Algorithms', '1', 2024, 'completed', 79, 'B+', 16),
('202300004', '4CPS231', 'Computer Communications & Networks', '1', 2024, 'completed', 88, 'A', 16),

('202300004', '4AMT212', 'Intro to Operations Research', '2', 2024, 'completed', 84, 'A', 16),
('202300004', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2024, 'completed', 81, 'A', 16),
('202300004', '4CPS212', 'Software Engineering', '2', 2024, 'completed', 76, 'B+', 16),
('202300004', '4CPS232', 'Database Information Management I', '2', 2024, 'completed', 83, 'A', 16),

-- YEAR 3 - 2025 Semester 1 - COMPLETED
('202300004', '4AMT321', 'Applied Mathematical Methods', '1', 2025, 'completed', 85, 'A', 16),
('202300004', '4AMT331', 'Tensor Analysis', '1', 2025, 'completed', 88, 'A', 16),
('202300004', '4CPS311', 'Advanced Programming Techniques', '1', 2025, 'completed', 82, 'A', 16),
('202300004', '4CPS321', 'Systems Programming (OS & Compilers)', '1', 2025, 'completed', 79, 'B+', 16),

-- YEAR 3 - 2025 Semester 2 - REGISTERED (NO MARKS)
('202300004', '4AMT312', 'Advanced Classical Mechanics', '2', 2025, 'registered', NULL, NULL, 0),
('202300004', '4AMT322', 'Numerical Methods', '2', 2025, 'registered', NULL, NULL, 0),
('202300004', '4CPS312', 'Distributed Systems Development', '2', 2025, 'registered', NULL, NULL, 0),
('202300004', '4CPS322', 'Final Year Project', '2', 2025, 'registered', NULL, NULL, 0);

-- Continue with SECOND YEAR STUDENTS (2024 intake) complete records
-- THABO MOKOENA (202400001) - 4BSC01 - Complete 2-year history
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2024
('202400001', '4AMT111', 'Discrete Mathematics', '1', 2024, 'completed', 71, 'B', 16),
('202400001', '4MTH111', 'Calculus I', '1', 2024, 'completed', 69, 'C+', 16),
('202400001', '4CPS111', 'Introductory Computing', '1', 2024, 'completed', 75, 'B+', 16),
('202400001', '4CPS121', 'Computer Literacy I', '1', 2024, 'completed', 62, 'C+', 16),
('202400001', '4STT111', 'Elementary Statistics for Science Students', '1', 2024, 'completed', 68, 'C+', 16),

('202400001', '4AMT122', 'Further Discrete Mathematics', '2', 2024, 'completed', 73, 'B', 16),
('202400001', '4MTH112', 'Calculus II', '2', 2024, 'completed', 66, 'C+', 16),
('202400001', '4CPS112', 'Intro to Systems Programming', '2', 2024, 'completed', 70, 'B', 16),
('202400001', '4CPS122', 'Computer Literacy II', '2', 2024, 'completed', 58, 'D+', 16),
('202400001', '4STT112', 'Statistics for Science Students', '2', 2024, 'completed', 72, 'B', 16),

-- YEAR 2 - 2025 Semester 1 - COMPLETED
('202400001', '4AMT211', 'Dynamical Systems & Mathematical Modelling', '1', 2025, 'completed', 74, 'B', 16),
('202400001', '4MTH221', 'Advanced Calculus', '1', 2025, 'completed', 68, 'C+', 16),
('202400001', '4CPS211', 'Data Structures and Algorithms', '1', 2025, 'completed', 72, 'B', 16),
('202400001', '4CPS231', 'Computer Communications & Networks', '1', 2025, 'completed', 65, 'C+', 16),

-- YEAR 2 - 2025 Semester 2 - REGISTERED (NO MARKS)
('202400001', '4AMT212', 'Intro to Operations Research', '2', 2025, 'registered', NULL, NULL, 0),
('202400001', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2025, 'registered', NULL, NULL, 0),
('202400001', '4CPS212', 'Software Engineering', '2', 2025, 'registered', NULL, NULL, 0),
('202400001', '4CPS232', 'Database Information Management I', '2', 2025, 'registered', NULL, NULL, 0);

-- PRECIOUS MBATHA (202400002) - 4BSC21 - Complete 2-year history
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2024
('202400002', '4AMT111', 'Discrete Mathematics', '1', 2024, 'completed', 74, 'B', 16),
('202400002', '4MTH111', 'Calculus I', '1', 2024, 'completed', 71, 'B', 16),
('202400002', '4CPS111', 'Introductory Computing', '1', 2024, 'completed', 68, 'C+', 16),
('202400002', '4CPS121', 'Computer Literacy I', '1', 2024, 'completed', 72, 'B', 16),
('202400002', '4STT111', 'Elementary Statistics for Science Students', '1', 2024, 'completed', 75, 'B+', 16),

('202400002', '4AMT122', 'Further Discrete Mathematics', '2', 2024, 'completed', 76, 'B+', 16),
('202400002', '4MTH112', 'Calculus II', '2', 2024, 'completed', 69, 'C+', 16),
('202400002', '4CPS112', 'Intro to Systems Programming', '2', 2024, 'completed', 73, 'B', 16),
('202400002', '4CPS122', 'Computer Literacy II', '2', 2024, 'completed', 75, 'B+', 16),
('202400002', '4STT112', 'Statistics for Science Students', '2', 2024, 'completed', 70, 'B', 16),

-- YEAR 2 - 2025 Semester 1 - COMPLETED
('202400002', '4AMT211', 'Dynamical Systems & Mathematical Modelling', '1', 2025, 'completed', 78, 'B+', 16),
('202400002', '4MTH221', 'Advanced Calculus', '1', 2025, 'completed', 82, 'A', 16),
('202400002', '4CPS211', 'Data Structures and Algorithms', '1', 2025, 'completed', 75, 'B+', 16),
('202400002', '4CPS231', 'Computer Communications & Networks', '1', 2025, 'completed', 79, 'B+', 16),

-- YEAR 2 - 2025 Semester 2 - REGISTERED (NO MARKS)
('202400002', '4AMT212', 'Intro to Operations Research', '2', 2025, 'registered', NULL, NULL, 0),
('202400002', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2025, 'registered', NULL, NULL, 0),
('202400002', '4CPS212', 'Software Engineering', '2', 2025, 'registered', NULL, NULL, 0),
('202400002', '4CPS232', 'Database Information Management I', '2', 2025, 'registered', NULL, NULL, 0);

-- AMANDA CELE (202400006) - 4BSC22 - Complete 2-year history
-- CHANGED: Removed 1 module from second semester second year
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- YEAR 1 - 2024
('202400006', '4AMT111', 'Discrete Mathematics', '1', 2024, 'completed', 70, 'B', 16),
('202400006', '4MTH111', 'Calculus I', '1', 2024, 'completed', 68, 'C+', 16),
('202400006', '4CPS111', 'Introductory Computing', '1', 2024, 'completed', 72, 'B', 16),
('202400006', '4CPS121', 'Computer Literacy I', '1', 2024, 'completed', 65, 'C+', 16),
('202400006', '4PHY111', 'Classical Mechanics & Properties of Matter', '1', 2024, 'completed', 75, 'B+', 16),

('202400006', '4AMT122', 'Further Discrete Mathematics', '2', 2024, 'completed', 73, 'B', 16),
('202400006', '4MTH112', 'Calculus II', '2', 2024, 'completed', 70, 'B', 16),
('202400006', '4CPS112', 'Intro to Systems Programming', '2', 2024, 'completed', 68, 'C+', 16),
('202400006', '4CPS122', 'Computer Literacy II', '2', 2024, 'completed', 71, 'B', 16),
('202400006', '4PHY112', 'Electromagnetism, Nuclear & Modern Physics', '2', 2024, 'completed', 78, 'B+', 16),

-- YEAR 2 - 2025 Semester 1 - COMPLETED
('202400006', '4PHY211', 'Mechanics Special Relativity & Properties of Matter', '1', 2025, 'completed', 80, 'A', 16),
('202400006', '4PHY222', 'Electromagnetism', '1', 2025, 'completed', 76, 'B+', 16),
('202400006', '4MTH221', 'Advanced Calculus', '1', 2025, 'completed', 72, 'B', 16),
('202400006', '4CPS211', 'Data Structures and Algorithms', '1', 2025, 'completed', 69, 'C+', 16),

-- YEAR 2 - 2025 Semester 2 - CHANGED: Removed 1 module (keeping only 3 instead of 4) - NOW REGISTERED (NO MARKS)
('202400006', '4PHY212', 'Modern Physics, Photonics & Waves', '2', 2025, 'registered', NULL, NULL, 0),
('202400006', '4MTH222', 'Linear Algebra & Differential Equations', '2', 2025, 'registered', NULL, NULL, 0),
('202400006', '4CPS212', 'Software Engineering', '2', 2025, 'registered', NULL, NULL, 0);
-- Removed: 4CPS232 module

-- =============================================================================
-- CREATE FIRST YEAR STUDENT ACADEMIC RECORDS WITH PASSED MODULES
-- =============================================================================

-- First Year Students - Semester 1 2025 Completed Modules
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned) VALUES
-- 4BSC01 Students
('202500001', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 72, 'B', 16),
('202500001', '4MTH111', 'Calculus I', '1', 2025, 'completed', 68, 'C+', 16),
('202500001', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 75, 'B+', 16),
('202500001', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 70, 'B', 16),
('202500001', '4STT111', 'Elementary Statistics for Science Students', '1', 2025, 'completed', 65, 'C+', 16),

('202500004', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 78, 'B+', 16),
('202500004', '4MTH111', 'Calculus I', '1', 2025, 'completed', 82, 'A', 16),
('202500004', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 74, 'B', 16),
('202500004', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 79, 'B+', 16),
('202500004', '4STT111', 'Elementary Statistics for Science Students', '1', 2025, 'completed', 71, 'B', 16),

('202500007', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 65, 'C+', 16),
('202500007', '4MTH111', 'Calculus I', '1', 2025, 'completed', 58, 'D+', 16),
('202500007', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 72, 'B', 16),
('202500007', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 68, 'C+', 16),
('202500007', '4STT111', 'Elementary Statistics for Science Students', '1', 2025, 'completed', 62, 'C+', 16),

('202500010', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 85, 'A', 16),
('202500010', '4MTH111', 'Calculus I', '1', 2025, 'completed', 88, 'A', 16),
('202500010', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 82, 'A', 16),
('202500010', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 79, 'B+', 16),
('202500010', '4STT111', 'Elementary Statistics for Science Students', '1', 2025, 'completed', 84, 'A', 16),

-- 4BSC21 Students
('202500002', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 70, 'B', 16),
('202500002', '4MTH111', 'Calculus I', '1', 2025, 'completed', 74, 'B', 16),
('202500002', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 68, 'C+', 16),
('202500002', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 72, 'B', 16),
('202500002', '4STT111', 'Elementary Statistics for Science Students', '1', 2025, 'completed', 76, 'B+', 16),

('202500005', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 79, 'B+', 16),
('202500005', '4MTH111', 'Calculus I', '1', 2025, 'completed', 75, 'B+', 16),
('202500005', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 81, 'A', 16),
('202500005', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 77, 'B+', 16),
('202500005', '4STT111', 'Elementary Statistics for Science Students', '1', 2025, 'completed', 73, 'B', 16),

('202500008', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 62, 'C+', 16),
('202500008', '4MTH111', 'Calculus I', '1', 2025, 'completed', 67, 'C+', 16),
('202500008', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 71, 'B', 16),
('202500008', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 65, 'C+', 16),
('202500008', '4STT111', 'Elementary Statistics for Science Students', '1', 2025, 'completed', 69, 'C+', 16),

-- 4BSC22 Students
('202500003', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 76, 'B+', 16),
('202500003', '4MTH111', 'Calculus I', '1', 2025, 'completed', 80, 'A', 16),
('202500003', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 74, 'B', 16),
('202500003', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 78, 'B+', 16),
('202500003', '4PHY111', 'Classical Mechanics & Properties of Matter', '1', 2025, 'completed', 82, 'A', 16),

('202500006', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 69, 'C+', 16),
('202500006', '4MTH111', 'Calculus I', '1', 2025, 'completed', 73, 'B', 16),
('202500006', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 67, 'C+', 16),
('202500006', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 71, 'B', 16),
('202500006', '4PHY111', 'Classical Mechanics & Properties of Matter', '1', 2025, 'completed', 75, 'B+', 16),

('202500009', '4AMT111', 'Discrete Mathematics', '1', 2025, 'completed', 83, 'A', 16),
('202500009', '4MTH111', 'Calculus I', '1', 2025, 'completed', 87, 'A', 16),
('202500009', '4CPS111', 'Introductory Computing', '1', 2025, 'completed', 79, 'B+', 16),
('202500009', '4CPS121', 'Computer Literacy I', '1', 2025, 'completed', 85, 'A', 16),
('202500009', '4PHY111', 'Classical Mechanics & Properties of Matter', '1', 2025, 'completed', 81, 'A', 16);

-- =============================================================================
-- ADD CURRENT SEMESTER REGISTRATIONS FOR FIRST YEAR STUDENTS (SEMESTER 2 2025)
-- =============================================================================

-- First Year Students - ALL REGISTERED FOR SEMESTER 2 2025 (NO MARKS)
INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned)
SELECT 
    s.username,
    pm.module_code,
    pm.module_name,
    '2',
    2025,
    'registered',
    NULL,
    NULL,
    0
FROM students s
JOIN program_modules pm ON ',' || pm.program_codes || ',' LIKE '%,' || s.program_code || ',%'
WHERE s.year_level = 1
AND pm.year_level = 1
AND pm.semester = 'Semester 2'
AND s.username IN ('202500001', '202500002', '202500003', '202500004', '202500005', 
                  '202500006', '202500007', '202500008', '202500009', '202500010');

-- =============================================================================
-- COMPREHENSIVE ACADEMIC RECORDS INSERTION
-- =============================================================================

-- Clear existing academic records
DELETE FROM academic_records;

-- Insert comprehensive academic records for all completed modules
INSERT INTO academic_records (username, module_code, module_name, semester, academic_year, final_mark, grade, credits_earned, status, program_code, year_level)
SELECT 
    sm.username,
    sm.module_code,
    sm.module_name,
    sm.semester,
    sm.academic_year,
    sm.final_mark,
    sm.grade,
    sm.credits_earned,
    CASE 
        WHEN sm.status = 'completed' AND sm.final_mark >= 50 THEN 'Completed'
        WHEN sm.status = 'completed' AND sm.final_mark < 50 THEN 'Failed'
        WHEN sm.status = 'withdrawn' THEN 'Withdrawn'
        ELSE 'Registered'
    END as status,
    s.program_code,
    -- Calculate the year level at the time the module was taken
    CASE 
        WHEN sm.academic_year = 2023 THEN 1
        WHEN sm.academic_year = 2024 THEN 
            CASE WHEN s.year_level = 3 THEN 2 ELSE 1 END
        WHEN sm.academic_year = 2025 THEN s.year_level
        ELSE s.year_level
    END as year_level
FROM student_modules sm
JOIN students s ON sm.username = s.username
WHERE sm.status = 'completed'
ORDER BY sm.username, sm.academic_year, sm.semester;

-- =============================================================================
-- UPDATE STUDENT CREDITS AND PROGRESS BASED ON ACADEMIC RECORDS
-- =============================================================================

-- Update student total credits earned from academic records
UPDATE students 
SET total_credits_earned = (
    SELECT COALESCE(SUM(credits_earned), 0) 
    FROM academic_records 
    WHERE academic_records.username = students.username 
    AND academic_records.status = 'Completed'
)
WHERE enrollment_status = 'active';

-- Clear and update student yearly progress from academic records
DELETE FROM student_yearly_progress;

INSERT INTO student_yearly_progress (username, academic_year, year_level, credits_earned, credits_remaining)
SELECT 
    ar.username,
    ar.academic_year,
    ar.year_level,
    SUM(ar.credits_earned) as credits_earned,
    ycl.max_credits - SUM(ar.credits_earned) as credits_remaining
FROM academic_records ar
JOIN students s ON ar.username = s.username
JOIN yearly_credit_limits ycl ON ar.year_level = ycl.year_level
WHERE ar.status = 'Completed'
GROUP BY ar.username, ar.academic_year, ar.year_level, ycl.max_credits;

-- =============================================================================
-- ALL DASHBOARD VIEWS (REMAIN UNCHANGED - EXACTLY AS IN ORIGINAL CODE)
-- =============================================================================

-- [All view definitions remain exactly the same as in your original code]
-- Student Dashboard View
CREATE VIEW student_dashboard AS
SELECT 
    s.username,
    s.first_name,
    s.last_name,
    s.program_code,
    s.year_level,
    s.total_credits_earned,
    sm.module_code,
    sm.module_name,
    sm.semester,
    sm.academic_year,
    sm.status as module_status,
    sm.final_mark,
    sm.grade,
    sm.credits_earned,
    mr.request_id,
    mr.module_code as request_module,
    mr.request_type,
    mr.reason,
    mr.status as request_status,
    mr.created_at as request_date
FROM students s
LEFT JOIN student_modules sm ON s.username = sm.username 
    AND sm.academic_year = 2025 
    AND sm.semester = '2'
LEFT JOIN modification_requests mr ON s.username = mr.username 
    AND mr.status IN ('pending_lecturer', 'pending_hod', 'pending_admin')
WHERE s.enrollment_status = 'active';

-- Student Academic History View
CREATE VIEW student_academic_history AS
SELECT 
    s.username,
    s.first_name,
    s.last_name,
    s.program_code,
    sm.module_code,
    sm.module_name,
    sm.semester,
    sm.academic_year,
    sm.final_mark,
    sm.grade,
    sm.credits_earned,
    sm.status
FROM students s
JOIN student_modules sm ON s.username = sm.username 
WHERE sm.status = 'completed'
ORDER BY sm.academic_year DESC, sm.semester DESC;

-- Enhanced Academic Record View
CREATE VIEW enhanced_academic_record AS
SELECT 
    s.username,
    s.first_name,
    s.last_name,
    s.program_code,
    p.program_name,
    s.year_level,
    s.total_credits_earned,
    sm.module_code,
    sm.module_name,
    pm.credits as module_credits,
    pm.nqf_level,
    pm.year_level as module_year,
    sm.semester,
    sm.academic_year,
    sm.final_mark,
    sm.grade,
    sm.credits_earned,
    sm.status as module_status,
    CASE 
        WHEN sm.status = 'completed' THEN 'Completed'
        WHEN sm.status = 'registered' THEN 'In Progress'
        ELSE sm.status
    END as display_status,
    ROUND((s.total_credits_earned * 100.0 / p.total_credits), 2) as degree_progress_percent,
    ycl.max_credits as yearly_credit_limit,
    COALESCE(syp.credits_earned, 0) as yearly_credits_earned,
    COALESCE(syp.credits_remaining, ycl.max_credits) as yearly_credits_remaining
FROM students s
JOIN programs p ON s.program_code = p.program_code
JOIN yearly_credit_limits ycl ON s.year_level = ycl.year_level
LEFT JOIN student_modules sm ON s.username = sm.username
LEFT JOIN program_modules pm ON sm.module_code = pm.module_code
LEFT JOIN student_yearly_progress syp ON s.username = syp.username 
    AND sm.academic_year = syp.academic_year
WHERE s.enrollment_status = 'active'
ORDER BY sm.academic_year DESC, sm.semester DESC, sm.module_code;

-- Lecturer dashboard: show requests for modules the lecturer teaches
CREATE VIEW lecturer_dashboard AS
SELECT
    ma.lecturer_username,
    ma.module_code,
    COALESCE(pm.module_name, ma.module_code) AS module_name,
    mr.request_id,
    mr.username        AS student_username,
    s.first_name,
    s.last_name,
    mr.request_type,
    mr.reason,
    mr.status          AS request_status,
    mr.created_at      AS request_date,
    mr.lecturer_username AS assigned_lecturer,
    mr.lecturer_comment,
    mr.lecturer_signed_at,
    mr.hod_username,
    mr.admin_username
FROM module_assignments ma
JOIN modification_requests mr
    ON ma.module_code = mr.module_code
LEFT JOIN students s
    ON s.username = mr.username
LEFT JOIN program_modules pm
    ON pm.module_code = ma.module_code
WHERE mr.status IN ('pending_lecturer', 'pending_hod', 'pending_admin');

-- HOD Dashboard View: Show requests pending HOD approval for their department
CREATE VIEW hod_dashboard AS
SELECT
    h.username as hod_username,
    h.department,
    mr.request_id,
    mr.username as student_username,
    s.first_name,
    s.last_name,
    s.program_code,
    mr.module_code,
    pm.module_name,
    mr.request_type,
    mr.reason,
    mr.status as request_status,
    mr.created_at as request_date,
    mr.lecturer_username,
    l.last_name as lecturer_name,
    mr.lecturer_comment,
    mr.lecturer_signed_at
FROM hods h
JOIN modification_requests mr ON h.department = (
    SELECT department FROM program_modules WHERE module_code = mr.module_code
)
JOIN students s ON mr.username = s.username
JOIN program_modules pm ON mr.module_code = pm.module_code
LEFT JOIN lecturers l ON mr.lecturer_username = l.username
WHERE mr.status IN ('pending_hod', 'pending_admin')
ORDER BY mr.created_at DESC;

-- Admin Dashboard View: Show all requests and system overview
CREATE VIEW admin_dashboard AS
SELECT
    a.username as admin_username,
    mr.request_id,
    mr.username as student_username,
    s.first_name as student_first_name,
    s.last_name as student_last_name,
    s.program_code,
    p.program_name,
    mr.module_code,
    pm.module_name,
    mr.request_type,
    mr.reason,
    mr.status as request_status,
    mr.created_at as request_date,
    mr.lecturer_username,
    l.last_name as lecturer_name,
    mr.lecturer_comment,
    mr.lecturer_signed_at,
    mr.hod_username,
    h.last_name as hod_name,
    mr.hod_comment,
    mr.hod_recommended_at
FROM admins a
JOIN modification_requests mr ON 1=1
JOIN students s ON mr.username = s.username
JOIN programs p ON s.program_code = p.program_code
JOIN program_modules pm ON mr.module_code = pm.module_code
LEFT JOIN lecturers l ON mr.lecturer_username = l.username
LEFT JOIN hods h ON mr.hod_username = h.username
ORDER BY mr.created_at DESC;

-- Department Overview View for HODs
CREATE VIEW department_overview AS
SELECT
    h.username as hod_username,
    h.department,
    COUNT(DISTINCT l.username) as total_lecturers,
    COUNT(DISTINCT ma.module_code) as total_modules,
    COUNT(DISTINCT s.username) as total_students,
    COUNT(DISTINCT mr.request_id) as pending_requests,
    AVG(sm.final_mark) as avg_department_mark
FROM hods h
LEFT JOIN lecturers l ON h.department = l.department
LEFT JOIN module_assignments ma ON l.username = ma.lecturer_username
LEFT JOIN students s ON s.program_code IN (
    SELECT program_code FROM programs WHERE departments LIKE '%' || h.department || '%'
)
LEFT JOIN modification_requests mr ON mr.module_code IN (
    SELECT module_code FROM program_modules WHERE department = h.department
) AND mr.status IN ('pending_hod', 'pending_admin')
LEFT JOIN student_modules sm ON sm.module_code IN (
    SELECT module_code FROM program_modules WHERE department = h.department
) AND sm.status = 'completed'
GROUP BY h.username, h.department;

-- System Overview View for Admins
CREATE VIEW system_overview AS
SELECT
    COUNT(DISTINCT s.username) as total_students,
    COUNT(DISTINCT l.username) as total_lecturers,
    COUNT(DISTINCT h.username) as total_hods,
    COUNT(DISTINCT p.program_code) as total_programs,
    COUNT(DISTINCT pm.module_code) as total_modules,
    COUNT(DISTINCT mr.request_id) as total_requests,
    COUNT(DISTINCT mr.request_id) as pending_requests,
    AVG(s.total_credits_earned) as avg_credits_earned,
    AVG(sm.final_mark) as avg_final_mark
FROM students s
CROSS JOIN lecturers l
CROSS JOIN hods h
CROSS JOIN programs p
CROSS JOIN program_modules pm
CROSS JOIN modification_requests mr
CROSS JOIN student_modules sm
WHERE s.enrollment_status = 'active'
AND sm.status = 'completed'
AND mr.status IN ('pending_lecturer', 'pending_hod', 'pending_admin')
LIMIT 1;

-- =============================================================================
-- ENHANCED ACADEMIC RECORDS VIEWS
-- =============================================================================

-- Comprehensive Academic Transcript View
CREATE VIEW comprehensive_academic_transcript AS
SELECT 
    s.username,
    s.first_name || ' ' || s.last_name as student_name,
    s.program_code,
    p.program_name,
    p.total_credits as degree_total_credits,
    s.total_credits_earned,
    ROUND((s.total_credits_earned * 100.0 / p.total_credits), 2) as degree_progress_percent,
    ar.academic_year,
    CASE 
        WHEN ar.academic_year = 2023 THEN 'First Year'
        WHEN ar.academic_year = 2024 THEN 'Second Year'
        WHEN ar.academic_year = 2025 THEN 
            CASE 
                WHEN s.year_level = 1 THEN 'First Year'
                WHEN s.year_level = 2 THEN 'Second Year' 
                WHEN s.year_level = 3 THEN 'Third Year'
                ELSE 'Year ' || s.year_level
            END
        ELSE 'Year ' || ar.year_level
    END as academic_year_label,
    CASE ar.semester
        WHEN '1' THEN 'Semester 1'
        WHEN '2' THEN 'Semester 2'
        ELSE ar.semester
    END as semester_label,
    ar.module_code,
    ar.module_name,
    pm.credits as module_possible_credits,
    ar.final_mark,
    ar.grade,
    ar.credits_earned,
    ar.status as module_status,
    pm.nqf_level,
    pm.department,
    CASE 
        WHEN ar.final_mark >= 75 THEN 'Distinction'
        WHEN ar.final_mark >= 70 THEN 'Merit'
        WHEN ar.final_mark >= 50 THEN 'Pass'
        WHEN ar.status = 'Withdrawn' THEN 'Withdrawn'
        ELSE 'Fail'
    END as performance_category
FROM students s
JOIN programs p ON s.program_code = p.program_code
JOIN academic_records ar ON s.username = ar.username
LEFT JOIN program_modules pm ON ar.module_code = pm.module_code
WHERE s.enrollment_status = 'active'
ORDER BY ar.username, ar.academic_year, ar.semester, ar.module_code;

-- Student Graduation Tracking View
CREATE VIEW student_graduation_tracking AS
SELECT 
    s.username,
    s.first_name || ' ' || s.last_name as student_name,
    s.program_code,
    p.program_name,
    s.year_level,
    s.total_credits_earned,
    p.total_credits as required_credits,
    p.total_credits - s.total_credits_earned as credits_remaining,
    ROUND((s.total_credits_earned * 100.0 / p.total_credits), 2) as completion_percentage,
    CASE 
        WHEN s.total_credits_earned >= p.total_credits THEN 'Eligible for Graduation'
        WHEN s.total_credits_earned >= p.total_credits * 0.75 THEN 'Final Year - Near Completion'
        WHEN s.total_credits_earned >= p.total_credits * 0.5 THEN 'Mid-Program'
        WHEN s.total_credits_earned >= p.total_credits * 0.25 THEN 'Early Stage'
        ELSE 'Beginning Stage'
    END as graduation_status,
    COUNT(ar.id) as total_modules_attempted,
    SUM(CASE WHEN ar.status = 'Completed' THEN 1 ELSE 0 END) as modules_completed,
    SUM(CASE WHEN ar.status = 'Failed' THEN 1 ELSE 0 END) as modules_failed,
    SUM(CASE WHEN ar.status = 'Withdrawn' THEN 1 ELSE 0 END) as modules_withdrawn,
    ROUND(AVG(CASE WHEN ar.status = 'Completed' THEN ar.final_mark ELSE NULL END), 2) as average_mark
FROM students s
JOIN programs p ON s.program_code = p.program_code
LEFT JOIN academic_records ar ON s.username = ar.username
WHERE s.enrollment_status = 'active'
GROUP BY s.username, s.first_name, s.last_name, s.program_code, p.program_name, s.year_level, s.total_credits_earned, p.total_credits;

-- Academic Performance Analytics View
CREATE VIEW academic_performance_analytics AS
SELECT 
    p.program_code,
    p.program_name,
    ar.academic_year,
    ar.year_level,
    pm.department,
    COUNT(ar.id) as total_modules,
    SUM(CASE WHEN ar.status = 'Completed' THEN 1 ELSE 0 END) as completed_modules,
    SUM(CASE WHEN ar.status = 'Failed' THEN 1 ELSE 0 END) as failed_modules,
    SUM(CASE WHEN ar.status = 'Withdrawn' THEN 1 ELSE 0 END) as withdrawn_modules,
    ROUND(AVG(CASE WHEN ar.status = 'Completed' THEN ar.final_mark ELSE NULL END), 2) as average_mark,
    ROUND((SUM(CASE WHEN ar.status = 'Completed' THEN 1 ELSE 0 END) * 100.0 / COUNT(ar.id)), 2) as success_rate,
    COUNT(DISTINCT ar.username) as total_students,
    SUM(ar.credits_earned) as total_credits_earned
FROM academic_records ar
JOIN students s ON ar.username = s.username
JOIN programs p ON s.program_code = p.program_code
JOIN program_modules pm ON ar.module_code = pm.module_code
GROUP BY p.program_code, p.program_name, ar.academic_year, ar.year_level, pm.department
ORDER BY p.program_code, ar.academic_year DESC, ar.year_level;

-- =============================================================================
-- FIXED ACADEMIC HISTORY VIEWS FOR FLASK
-- =============================================================================

-- FIXED Student Academic History View - Shows ALL modules from ALL years
CREATE VIEW student_academic_history_fixed AS
SELECT 
    s.username,
    s.first_name,
    s.last_name,
    s.program_code,
    p.program_name,
    sm.module_code,
    pm.module_name,
    sm.semester,
    sm.academic_year,
    CASE 
        WHEN sm.academic_year = 2023 THEN 'First Year'
        WHEN sm.academic_year = 2024 THEN 'Second Year' 
        WHEN sm.academic_year = 2025 AND s.year_level = 2 THEN 'Second Year'
        WHEN sm.academic_year = 2025 AND s.year_level = 3 THEN 'Third Year'
        ELSE 'Year ' || CAST(s.year_level AS TEXT)
    END as academic_year_label,
    CASE 
        WHEN sm.semester = '1' THEN 'Semester 1'
        WHEN sm.semester = '2' THEN 'Semester 2'
        ELSE sm.semester
    END as semester_label,
    sm.final_mark,
    sm.grade,
    sm.credits_earned,
    pm.credits as possible_credits,
    pm.nqf_level,
    sm.status,
    CASE 
        WHEN sm.status = 'completed' AND sm.final_mark >= 50 THEN 'Passed'
        WHEN sm.status = 'completed' AND sm.final_mark < 50 THEN 'Failed'
        WHEN sm.status = 'registered' THEN 'In Progress'
        ELSE sm.status
    END as result_status
FROM students s
JOIN programs p ON s.program_code = p.program_code
JOIN student_modules sm ON s.username = sm.username
JOIN program_modules pm ON sm.module_code = pm.module_code
WHERE s.enrollment_status = 'active'
ORDER BY sm.academic_year DESC, sm.semester DESC, sm.module_code;

-- Enhanced Academic Record View with better organization
CREATE VIEW enhanced_academic_record_fixed AS
SELECT 
    s.username,
    s.first_name || ' ' || s.last_name as student_name,
    s.program_code,
    p.program_name,
    s.year_level as current_year,
    s.total_credits_earned,
    ROUND((s.total_credits_earned * 100.0 / p.total_credits), 2) as degree_progress_percent,
    sm.academic_year,
    CASE 
        WHEN sm.academic_year = 2023 THEN 'First Year'
        WHEN sm.academic_year = 2024 THEN 'Second Year'
        WHEN sm.academic_year = 2025 AND s.year_level = 2 THEN 'Second Year'
        WHEN sm.academic_year = 2025 AND s.year_level = 3 THEN 'Third Year'
        ELSE 'Year ' || CAST(s.year_level AS TEXT)
    END as academic_year_label,
    sm.semester,
    CASE sm.semester
        WHEN '1' THEN 'Semester 1'
        WHEN '2' THEN 'Semester 2'
        ELSE sm.semester
    END as semester_label,
    sm.module_code,
    sm.module_name,
    pm.credits as module_credits,
    sm.final_mark,
    sm.grade,
    sm.credits_earned,
    CASE 
        WHEN sm.status = 'completed' AND sm.final_mark >= 50 THEN 'Passed'
        WHEN sm.status = 'completed' AND sm.final_mark < 50 THEN 'Failed'
        WHEN sm.status = 'registered' THEN 'Registered'
        ELSE sm.status
    END as module_result,
    pm.nqf_level,
    pm.department
FROM students s
JOIN programs p ON s.program_code = p.program_code
JOIN student_modules sm ON s.username = sm.username
JOIN program_modules pm ON sm.module_code = pm.module_code
WHERE s.enrollment_status = 'active'
ORDER BY sm.academic_year DESC, sm.semester DESC, sm.module_code;

-- =============================================================================
-- INDEXES FOR PERFORMANCE
-- =============================================================================

CREATE INDEX idx_modreq_module_code ON modification_requests(module_code);
CREATE INDEX idx_module_assign_lecturer ON module_assignments(lecturer_username);
CREATE INDEX idx_student_modules_username ON student_modules(username);
CREATE INDEX idx_student_modules_year ON student_modules(academic_year);
CREATE INDEX idx_modification_requests_status ON modification_requests(status);
CREATE INDEX idx_program_modules_program ON program_modules(program_codes);
CREATE INDEX idx_student_modules_status ON student_modules(status);
CREATE INDEX idx_academic_records_username ON academic_records(username);
CREATE INDEX idx_academic_records_status ON academic_records(status);
CREATE INDEX idx_academic_records_year ON academic_records(academic_year);
CREATE INDEX idx_academic_records_module ON academic_records(module_code);
CREATE INDEX idx_current_semester_program ON current_semester_tracking(program_code);
CREATE INDEX idx_acad_records_username_year ON academic_records(username, academic_year);
CREATE INDEX idx_acad_records_credits ON academic_records(credits_earned);
CREATE INDEX idx_students_credits ON students(total_credits_earned);

-- =============================================================================
-- VERIFICATION QUERIES FOR ALL DASHBOARDS
-- =============================================================================

-- Test Academic Records Insertion
SELECT '=== TEST: Academic Records Summary ===' as info;
SELECT 
    COUNT(*) as total_records,
    SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed_modules,
    SUM(CASE WHEN status = 'Failed' THEN 1 ELSE 0 END) as failed_modules,
    SUM(CASE WHEN status = 'Withdrawn' THEN 1 ELSE 0 END) as withdrawn_modules,
    SUM(credits_earned) as total_credits_earned
FROM academic_records;

-- Test Student Graduation Tracking
SELECT '=== TEST: Student Graduation Tracking ===' as info;
SELECT 
    student_name, 
    program_name, 
    year_level, 
    total_credits_earned, 
    required_credits,
    completion_percentage,
    graduation_status
FROM student_graduation_tracking 
ORDER BY completion_percentage DESC 
LIMIT 10;

-- Test Student Dashboard
SELECT '=== TEST: Student Dashboard ===' as info;
SELECT username, first_name, last_name, program_code, module_code, module_name, module_status
FROM student_dashboard 
WHERE username = '202400001';

-- Test Lecturer Dashboard
SELECT '=== TEST: Lecturer Dashboard ===' as info;
SELECT lecturer_username, module_code, module_name, student_username, first_name, last_name, request_type, request_status
FROM lecturer_dashboard 
WHERE lecturer_username = 'lecturer.cs1';

-- Test HOD Dashboard
SELECT '=== TEST: HOD Dashboard ===' as info;
SELECT hod_username, department, student_username, first_name, last_name, module_code, module_name, request_type, request_status
FROM hod_dashboard 
WHERE hod_username = 'hod.cs';

-- Test Admin Dashboard
SELECT '=== TEST: Admin Dashboard ===' as info;
SELECT admin_username, student_username, student_first_name, student_last_name, module_code, module_name, request_type, request_status
FROM admin_dashboard 
WHERE admin_username = 'admin1';

-- Test Comprehensive Transcript for a specific student
SELECT '=== TEST: Comprehensive Transcript for 230012566 ===' as info;
SELECT 
    academic_year_label,
    semester_label,
    module_code,
    module_name,
    final_mark,
    grade,
    credits_earned,
    performance_category
FROM comprehensive_academic_transcript 
WHERE username = '230012566'
ORDER BY academic_year, semester;

-- Test Academic Performance Analytics
SELECT '=== TEST: Academic Performance by Program ===' as info;
SELECT 
    program_code,
    program_name,
    academic_year,
    success_rate,
    average_mark,
    total_students
FROM academic_performance_analytics 
ORDER BY program_code, academic_year DESC;

-- Test Student Credits Update
SELECT '=== TEST: Student Credits Verification ===' as info;
SELECT 
    username,
    first_name,
    last_name,
    program_code,
    year_level,
    total_credits_earned
FROM students 
WHERE username IN ('202293688', '202300001', '202400001', '230012566')
ORDER BY year_level DESC;

-- =============================================================================
-- VERIFICATION OF SPECIFIC CHANGES
-- =============================================================================

SELECT '=== VERIFICATION OF SPECIFIC CHANGES ===' as info;

-- Verify 202293688 (Zethembe Gumede) - Should have only 2 modules in Year 3 Semester 2 (no computer modules)
SELECT '202293688 - Year 3 Semester 2 Modules (Should be 2 math modules only):' as verification;
SELECT username, module_code, module_name, semester, academic_year, status, final_mark
FROM student_modules 
WHERE username = '202293688' AND academic_year = 2025 AND semester = '2';

-- Verify 230012566 (Siyabuswa Mdletshe) - Should have 3 modules in Year 2 Semester 2 (removed 1)
SELECT '230012566 - Year 2 Semester 2 Modules (Should be 3 modules):' as verification;
SELECT username, module_code, module_name, semester, academic_year, status, final_mark
FROM student_modules 
WHERE username = '230012566' AND academic_year = 2025 AND semester = '2';

-- Verify 202294632 (Luxolo Mkhize) - Should have 4PHY112 in Year 3 Semester 2
SELECT '202294632 - Year 3 Semester 2 Modules (Should include 4PHY112):' as verification;
SELECT username, module_code, module_name, semester, academic_year, status, final_mark
FROM student_modules 
WHERE username = '202294632' AND academic_year = 2025 AND semester = '2';

-- Verify 202400006 (Amanda Cele) - Should have 3 modules in Year 2 Semester 2 (removed 1)
SELECT '202400006 - Year 2 Semester 2 Modules (Should be 3 modules):' as verification;
SELECT username, module_code, module_name, semester, academic_year, status, final_mark
FROM student_modules 
WHERE username = '202400006' AND academic_year = 2025 AND semester = '2';

-- Verify 202300002 (Xolani Mnguni) - Should have 4AMT322 in Year 3 Semester 2
SELECT '202300002 - Year 3 Semester 2 Modules (Should include 4AMT322):' as verification;
SELECT username, module_code, module_name, semester, academic_year, status, final_mark
FROM student_modules 
WHERE username = '202300002' AND academic_year = 2025 AND semester = '2';

-- Verify First Year Students have completed Semester 1 modules and registered for Semester 2
SELECT 'First Year Students - Semester 1 2025 Completed vs Semester 2 2025 Registered:' as verification;
SELECT username, 
       SUM(CASE WHEN semester = '1' AND status = 'completed' THEN 1 ELSE 0 END) as sem1_completed,
       SUM(CASE WHEN semester = '2' AND status = 'registered' THEN 1 ELSE 0 END) as sem2_registered
FROM student_modules 
WHERE username LIKE '202500%' AND academic_year = 2025
GROUP BY username;

-- Verify NO marks for Semester 2 2025 modules
SELECT '=== VERIFICATION: No Marks for Semester 2 2025 ===' as info;
SELECT COUNT(*) as modules_with_marks
FROM student_modules 
WHERE academic_year = 2025 AND semester = '2' AND final_mark IS NOT NULL;

-- =============================================================================
-- FINAL DATABASE STATUS
-- =============================================================================

SELECT '=== FINAL DATABASE STATUS ===' as info;
SELECT 
    (SELECT COUNT(*) FROM students) as total_students,
    (SELECT COUNT(*) FROM lecturers) as total_lecturers,
    (SELECT COUNT(*) FROM hods) as total_hods,
    (SELECT COUNT(*) FROM admins) as total_admins,
    (SELECT COUNT(*) FROM programs) as total_programs,
    (SELECT COUNT(*) FROM program_modules) as total_modules,
    (SELECT COUNT(*) FROM student_modules) as total_student_modules,
    (SELECT COUNT(*) FROM academic_records) as total_academic_records,
    (SELECT COUNT(*) FROM modification_requests) as total_requests;

SELECT '=== DATABASE READY FOR USE ===' as final_status;