#!/usr/bin/env python3
"""Create a SQLite database from the SQL script and write a brief setup log.

Usage: python scripts/create_db.py
"""
import sqlite3
import sys
import traceback
from pathlib import Path
from datetime import datetime


def main():
    base = Path(__file__).resolve().parents[1]
    sql_path = base / 'university_database.sql'
    db_path = base / 'database.db'
    log_path = base / 'database_setup_log.md'

    if not sql_path.exists():
        print(f"SQL file not found: {sql_path}")
        sys.exit(1)

    sql = sql_path.read_text(encoding='utf-8')

    try:
        conn = sqlite3.connect(str(db_path))
        cur = conn.cursor()
        print(f"Executing SQL script: {sql_path}")
        cur.executescript(sql)
        conn.commit()

        # list tables and views (exclude sqlite internal tables)
        cur.execute("SELECT type, name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY type, name;")
        rows = cur.fetchall()

        now = datetime.now().isoformat()
        lines = [
            f"# Database setup log",
            "",
            f"Created at: {now}",
            "",
            f"Database file: {db_path}",
            "",
            "## Objects",
            ""
        ]
        for typ, name in rows:
            lines.append(f"- {typ}: {name}")

        log_path.write_text("\n".join(lines), encoding='utf-8')

        print(f"Created database at: {db_path}")
        print("Objects:")
        for typ, name in rows:
            print(f"{typ}: {name}")
        print(f"Log written to: {log_path}")

    except Exception as e:
        print("Error running SQL:", e)
        traceback.print_exc()
        sys.exit(2)
    finally:
        try:
            conn.close()
        except Exception:
            pass


if __name__ == '__main__':
    main()
