#!/usr/bin/env python3
"""Check and print a user's stored password from database.db

Usage: python scripts/check_user.py <username>
"""
import sys
import sqlite3
from pathlib import Path

def main():
    if len(sys.argv) < 2:
        print('Usage: python scripts/check_user.py <username>')
        sys.exit(1)
    username = sys.argv[1]
    db = Path(__file__).resolve().parents[1] / 'database.db'
    if not db.exists():
        print('database.db not found at', db)
        sys.exit(2)
    conn = sqlite3.connect(str(db))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute('SELECT username, password FROM students WHERE username = ?', (username,))
    row = cur.fetchone()
    if row:
        print(row['username'], row['password'])
    else:
        print('Not found')
    conn.close()

if __name__ == '__main__':
    main()
